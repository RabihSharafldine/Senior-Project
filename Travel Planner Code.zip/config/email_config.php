<?php
// Email Configuration for Gmail
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '22230237@students.liu.edu.lb'); // Your Gmail address
define('SMTP_PASSWORD', 'yipg mepm nvlk vdpq'); // Gmail App Password (see below)
define('SMTP_FROM_EMAIL', '22230237@students.liu.edu.lb');
define('SMTP_FROM_NAME', 'TravelPlanner');
define('SMTP_SECURE', 'tls');
define('SMTP_AUTH', true);

define('SMTP_SSL_VERIFY', false);
// For other email providers:
// Outlook: smtp-mail.outlook.com, port 587
// Yahoo: smtp.mail.yahoo.com, port 587
// Hotmail: smtp.live.com, port 587
?>