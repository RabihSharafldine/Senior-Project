<?php
// config/chatbot_config.php
// DeepSeek Configuration
define('DEEPSEEK_API_KEY', 'sk-3a35c058e78944fa9b4f998bfdaf359a'); // Get from https://platform.deepseek.com/api_keys
define('USE_DEEPSEEK', true);
define('AI_CHATBOT_ENABLED', true);
?>