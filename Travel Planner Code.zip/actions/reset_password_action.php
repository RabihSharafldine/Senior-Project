<?php
session_start();
require_once '../connection.php';

error_log("=== RESET PASSWORD ACTION ===");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    error_log("🔐 Processing token: " . $token);

    try {
        // Find user with this token
        $stmt = $pdo->prepare("SELECT id, email FROM users WHERE reset_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            error_log("❌ Token not found");
            $_SESSION['reset_error'] = "Invalid reset token.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        error_log("✅ User found: " . $user['email']);

        // Validate passwords - UPDATED TO MATCH REGISTER REQUIREMENTS
        if ($new_password !== $confirm_password) {
            $_SESSION['reset_error'] = "Passwords do not match.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        // Enhanced password validation (same as register)
        if (strlen($new_password) < 8) {
            $_SESSION['reset_error'] = "Password must be at least 8 characters.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        if (!preg_match('/[A-Z]/', $new_password)) {
            $_SESSION['reset_error'] = "Password must contain at least one uppercase letter.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        if (!preg_match('/[0-9]/', $new_password)) {
            $_SESSION['reset_error'] = "Password must contain at least one number.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        if (!preg_match('/[!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?]/', $new_password)) {
            $_SESSION['reset_error'] = "Password must contain at least one special character.";
            header("Location: ../reset-password.php?token=" . $token);
            exit();
        }

        // Hash and update password + set email as verified
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        $updateStmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL, email_verified = 1 WHERE id = ?");
        $result = $updateStmt->execute([$hashed_password, $user['id']]);

        if ($result) {
            error_log("🎉 PASSWORD RESET SUCCESSFUL for: " . $user['email']);
            $_SESSION['login_success'] = "Password reset successfully! You can now login with your new password.";
            header("Location: ../login.php");
            exit();
        } else {
            throw new Exception("Password update failed");
        }

    } catch (Exception $e) {
        error_log("❌ Error: " . $e->getMessage());
        $_SESSION['reset_error'] = "System error. Please try again.";
        header("Location: ../reset-password.php?token=" . $token);
        exit();
    }
}

header("Location: ../forgot-password.php");
exit();
?>