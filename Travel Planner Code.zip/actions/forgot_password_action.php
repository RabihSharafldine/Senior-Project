<?php
session_start();
require_once '../connection.php';

require_once '../PHPMailer/PHPMailer.php';
require_once '../PHPMailer/SMTP.php';
require_once '../PHPMailer/Exception.php';
require_once '../config/email_config.php';

use PHPMailer\PHPMailer\PHPMailer;

error_log("=== FORGOT PASSWORD ACTION START ===");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    
    error_log("📧 Processing email: " . $email);

    try {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            error_log("✅ User found: " . $user['name']);
            
            // Generate reset token
            $reset_token = bin2hex(random_bytes(32));
            
            // Use database time for consistency
            $timeStmt = $pdo->query("SELECT DATE_ADD(NOW(), INTERVAL 2 HOUR) as expires_time");
            $timeResult = $timeStmt->fetch(PDO::FETCH_ASSOC);
            $expires = $timeResult['expires_time'];
            
            error_log("🔐 Generated token: " . $reset_token);
            error_log("⏰ Expires: " . $expires);
            
            // Store token in database
            $updateStmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
            $result = $updateStmt->execute([$reset_token, $expires, $email]);
            
            if ($result) {
                error_log("💾 Token stored in database");
                
                // Create reset link
                $reset_link = "http://localhost:3000/reset-password.php?token=" . $reset_token;
                error_log("🔗 Reset Link: " . $reset_link);
                
                // Send email using PHPMailer
                $mail = new PHPMailer(true);
                
                try {
                    $mail->isSMTP();
                    $mail->Host       = SMTP_HOST;
                    $mail->SMTPAuth   = SMTP_AUTH;
                    $mail->Username   = SMTP_USERNAME;
                    $mail->Password   = SMTP_PASSWORD;
                    $mail->SMTPSecure = SMTP_SECURE;
                    $mail->Port       = SMTP_PORT;
                    
                    $mail->SMTPOptions = array(
                        'ssl' => array(
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        )
                    );
                    
                    $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
                    $mail->addAddress($email, $user['name']);
                    
                    $mail->isHTML(true);
                    $mail->Subject = 'Password Reset Request - TravelPlanner';
                    
                $mail->Body = "
<!DOCTYPE html>
<html>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body { 
            font-family: 'Poppins', Arial, sans-serif; 
            line-height: 1.6; 
            color: #333; 
            margin: 0; 
            padding: 0; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .email-container { 
            max-width: 600px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            margin-top: 20px; 
            margin-bottom: 20px;
        }
        .email-header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
            position: relative;
        }
        .header-icon { 
            font-size: 48px; 
            margin-bottom: 15px; 
            display: block;
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
            40% {transform: translateY(-10px);}
            60% {transform: translateY(-5px);}
        }
        .email-header h1 { 
            margin: 0; 
            font-size: 28px; 
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .email-content { 
            padding: 40px 30px; 
            background: #f8fafc;
        }
        .welcome-section {
            text-align: center;
            margin-bottom: 30px;
        }
        .welcome-icon {
            font-size: 32px;
            color: #667eea;
            margin-bottom: 15px;
        }
        .user-greeting {
            font-size: 20px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 10px;
        }
        .reset-section {
            background: white;
            padding: 25px;
            border-radius: 15px;
            border-left: 4px solid #667eea;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            margin: 25px 0;
        }
        .reset-icon {
            font-size: 24px;
            color: #667eea;
            margin-right: 10px;
            vertical-align: middle;
        }
        .reset-button { 
            display: inline-block; 
            padding: 15px 35px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            text-decoration: none; 
            border-radius: 50px; 
            margin: 20px 0; 
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .reset-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        .link-backup {
            background: #f7fafc;
            padding: 15px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            margin: 20px 0;
            word-break: break-all;
            font-family: monospace;
            color: #4a5568;
        }
        .info-section {
            background: linear-gradient(135deg, #fed7e2 0%, #fed7d7 100%);
            padding: 20px;
            border-radius: 15px;
            margin: 25px 0;
            border-left: 4px solid #f56565;
        }
        .info-icon {
            font-size: 20px;
            color: #f56565;
            margin-right: 10px;
        }
        .security-note {
            background: linear-gradient(135deg, #c6f6d5 0%, #b2f5ea 100%);
            padding: 20px;
            border-radius: 15px;
            margin: 25px 0;
            border-left: 4px solid #48bb78;
        }
        .security-icon {
            font-size: 20px;
            color: #48bb78;
            margin-right: 10px;
        }
        .email-footer { 
            text-align: center; 
            padding: 30px; 
            background: #2d3748; 
            color: white;
            border-radius: 0 0 20px 20px;
        }
        .footer-logo {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 15px;
            color: #667eea;
        }
        .social-icons {
            margin: 20px 0;
        }
        .social-icon {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            margin: 0 5px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .social-icon:hover {
            background: #667eea;
            transform: translateY(-2px);
        }
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin: 25px 0;
        }
        .feature-item {
            text-align: center;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .feature-icon {
            font-size: 20px;
            color: #667eea;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='email-header'>
            <i class='fas fa-key header-icon'></i>
            <h1>Password Reset Request</h1>
            <p style='margin: 10px 0 0 0; opacity: 0.9;'>Let's get you back on track! </p>
        </div>
        
        <div class='email-content'>
            <div class='welcome-section'>
                <i class='fas fa-plane-departure welcome-icon'></i>
                <div class='user-greeting'>Hello " . htmlspecialchars($user['name']) . "! </div>
                <p style='color: #718096;'>We heard you need a password reset. No worries - adventures await!</p>
            </div>
            
            <div class='reset-section'>
                <p><i class='fas fa-sync-alt reset-icon'></i><strong>Ready to continue your journey?</strong></p>
                <p>Click the magical button below to create your new password and get back to planning amazing trips! </p>
                
                <div style='text-align: center;'>
                    <a href='$reset_link' class='reset-button'>
                        <i class='fas fa-rocket'></i> Reset My Password
                    </a>
                </div>
            </div>
            
            <div class='info-section'>
                <p><i class='fas fa-clock info-icon'></i><strong>Link expires in 2 hours</strong></p>
                <p>For your security, this reset link will automatically expire. If you need a new one, just request another password reset!</p>
            </div>
            
            <div class='security-note'>
                <p><i class='fas fa-shield-alt security-icon'></i><strong>Prefer to copy the link?</strong></p>
                <p>No problem! Paste this into your browser:</p>
                <div class='link-backup'>$reset_link</div>
            </div>
            
            <div style='text-align: center; margin: 30px 0;'>
                <p style='color: #718096; font-size: 14px;'>
                    <i class='fas fa-info-circle' style='color: #a0aec0;'></i>
                    If you didn't request this, your account is safe - just ignore this email. Your adventure continues! 
                </p>
            </div>
            
            <div class='feature-grid'>
                <div class='feature-item'>
                    <i class='fas fa-map-marked-alt feature-icon'></i>
                    <div style='font-size: 12px; color: #4a5568;'>Plan Trips</div>
                </div>
                <div class='feature-item'>
                    <i class='fas fa-hotel feature-icon'></i>
                    <div style='font-size: 12px; color: #4a5568;'>Book Stays</div>
                </div>
                <div class='feature-item'>
                    <i class='fas fa-users feature-icon'></i>
                    <div style='font-size: 12px; color: #4a5568;'>Share Memories</div>
                </div>
            </div>
        </div>
        
        <div class='email-footer'>
            <div class='footer-logo'>
                <i class='fas fa-compass'></i> TravelPlanner
            </div>
            <p style='margin: 0 0 20px 0; opacity: 0.8;'>Creating unforgettable journeys, one trip at a time</p>
            
        
            
            <p style='font-size: 12px; opacity: 0.6; margin: 20px 0 0 0;'>
                Safe travels and happy adventures!<br>
                The TravelPlanner Team 
            </p>
        </div>
    </div>
</body>
</html>
";
                    $mail->AltBody = "Password Reset Link: $reset_link\n\nThis link expires in 2 hours.";
                    
                    if($mail->send()) {
                        error_log("✅ Email sent successfully to: " . $email);
                        $_SESSION['forgot_message'] = "✅ Password reset link has been sent to your email! Check your inbox (and spam folder).";
                    } else {
                        throw new Exception("Email sending failed");
                    }
                    
                } catch (Exception $e) {
                    error_log("❌ Email error: " . $e->getMessage());
                    $_SESSION['forgot_error'] = "❌ Failed to send email. Please try again.";
                }
                
            } else {
                error_log("❌ Failed to store token in database");
                $_SESSION['forgot_error'] = "System error. Please try again.";
            }
            
        } else {
            error_log("❌ User not found with email: " . $email);
            $_SESSION['forgot_error'] = "No account found with that email address.";
        }
        
    } catch (PDOException $e) {
        error_log("❌ Database error: " . $e->getMessage());
        $_SESSION['forgot_error'] = "Database error. Please try again.";
    }
    
    header("Location: ../forgot-password.php");
    exit();
}
?>