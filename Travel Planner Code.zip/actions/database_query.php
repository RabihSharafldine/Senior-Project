<?php
// actions/database_query.php
require_once __DIR__ . '/../connection.php';
header('Content-Type: application/json');

if (!isset($_POST['query_type']) || !isset($_POST['search_term'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$queryType = $_POST['query_type'];
$searchTerm = $_POST['search_term'];
$response = ['success' => true, 'data' => []];

try {
    switch ($queryType) {
        case 'destinations':
            $stmt = $pdo->prepare("SELECT name, country, region, description FROM destinations WHERE name LIKE ? OR country LIKE ? LIMIT 5");
            $search = "%$searchTerm%";
            $stmt->execute([$search, $search]);
            $response['data'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'hotels':
            $stmt = $pdo->prepare("SELECT name, country, type, price_per_night, rating FROM accommodations WHERE name LIKE ? OR country LIKE ? LIMIT 5");
            $search = "%$searchTerm%";
            $stmt->execute([$search, $search]);
            $response['data'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'attractions':
            $stmt = $pdo->prepare("SELECT a.name, a.type, a.entry_fee, d.name as destination FROM attractions a JOIN destinations d ON a.destination_id = d.destination_id WHERE a.name LIKE ? OR d.name LIKE ? LIMIT 5");
            $search = "%$searchTerm%";
            $stmt->execute([$search, $search]);
            $response['data'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
    }
} catch (PDOException $e) {
    $response = ['success' => false, 'message' => 'Database query failed'];
}

echo json_encode($response);
?>