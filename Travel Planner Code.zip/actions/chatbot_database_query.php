<?php
// actions/chatbot_database_query.php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../connection.php';

$response = ['success' => false, 'data' => []];

try {
    if (!isset($_POST['query_type']) || !isset($_POST['search_term'])) {
        throw new Exception('Missing parameters');
    }
    
    $queryType = $_POST['query_type'];
    $searchTerm = trim($_POST['search_term']);
    
    if (empty($searchTerm)) {
        throw new Exception('Search term is empty');
    }
    
    switch($queryType) {
        case 'destinations':
            $stmt = $pdo->prepare("SELECT * FROM destinations WHERE name LIKE :term OR country LIKE :term LIMIT 5");
            $stmt->execute(['term' => "%$searchTerm%"]);
            break;
            
        case 'hotels':
            $stmt = $pdo->prepare("SELECT * FROM hotels WHERE location LIKE :term OR name LIKE :term LIMIT 5");
            $stmt->execute(['term' => "%$searchTerm%"]);
            break;
            
        case 'attractions':
            $stmt = $pdo->prepare("SELECT * FROM attractions WHERE location LIKE :term OR name LIKE :term LIMIT 5");
            $stmt->execute(['term' => "%$searchTerm%"]);
            break;
            
        default:
            throw new Exception('Invalid query type');
    }
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $response = [
        'success' => true,
        'data' => $data
    ];
    
} catch (Exception $e) {
    $response = [
        'success' => false, 
        'error' => $e->getMessage(),
        'data' => []
    ];
}

echo json_encode($response);
?>