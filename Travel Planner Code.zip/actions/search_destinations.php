<?php
session_start();
require_once "../connection.php";
header('Content-Type: application/json');





try {
    $searchTerm = isset($_GET['q']) ? trim($_GET['q']) : '';

    if (empty($searchTerm)) {
        echo json_encode(['success' => false, 'message' => 'Search term is required']);
        exit;
    }

    // Simple search query
    $sql = "SELECT * FROM destinations 
            WHERE name LIKE ? OR country LIKE ? 
            ORDER BY name ASC 
            LIMIT 10";
    
    $stmt = $pdo->prepare($sql);
    
    $searchPattern = "%$searchTerm%";
    $stmt->execute([$searchPattern, $searchPattern]);
    
    $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'destinations' => $destinations,
        'count' => count($destinations),
        'search_term' => $searchTerm // For debugging
    ]);

} catch(Exception $e) {
    // Make sure we return valid JSON even for errors
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
        'error_details' => 'Check database connection and table structure'
    ]);
}
?>