<?php
session_start();
require "../connection.php";

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $rememberMe = isset($_POST['rememberMe']) ? true : false; // Check if remember me was checked
    
    try { 
        $sql = "SELECT * FROM users WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        if($stmt->rowCount() > 0){
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if(password_verify($password, $user['password'])){
                // Check if email is verified (skip for admin emails)
                $adminEmails = [
                    'abouelezz_ghaith@travelplanner.com',
                    'sharafldinerabih@gmail.com'
                ];
                
                $isAdminEmail = in_array(strtolower($email), $adminEmails);
                
                if(!$isAdminEmail && isset($user['email_verified']) && $user['email_verified'] == 0) {
                    $_SESSION['login_error1'] = "Please verify your email before logging in. Check your inbox for the verification link.";
                    header("Location: ../login.php");
                    exit;
                }
                
                // Set session variables
                $_SESSION['loggedIn'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_username'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];
                
                // If "Remember Me" was checked, set a cookie
                if($rememberMe) {
                    // Create a remember token
                    $rememberToken = bin2hex(random_bytes(32));
                    $expiry = time() + (30 * 24 * 60 * 60); // 30 days from now
                    
                    // Store the token in database
                    $tokenSql = "UPDATE users SET remember_token = :token, token_expiry = :expiry WHERE id = :id";
                    $tokenStmt = $pdo->prepare($tokenSql);
                    $tokenStmt->execute([
                        ':token' => $rememberToken,
                        ':expiry' => date('Y-m-d H:i:s', $expiry),
                        ':id' => $user['id']
                    ]);
                    
                    // Set cookie (valid for 30 days)
                    setcookie('remember_me', $user['id'] . ':' . $rememberToken, $expiry, '/', '', false, true);
                }
                
                // Redirect admin emails to admin.php
                if(in_array($_SESSION['user_email'], $adminEmails)){
                    header("Location: ../admin.php");
                    exit();
                }
                
                header("Location: ../home.php");
                exit;
            } else {
                $_SESSION['login_error1'] = "Invalid email or password";
                header("Location: ../login.php");
                exit;
            }
        } else {
            $_SESSION['login_error1'] = "Invalid email or password";
            header("Location: ../login.php");
            exit;
        }
    } catch(PDOException $exc) {
        $_SESSION['login_error1'] = "Login failed. Please try again.";
        header("Location: ../login.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>