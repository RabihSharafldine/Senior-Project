<?php
// Add strict session configuration at the VERY TOP
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
ini_set('session.use_strict_mode', 1);

session_start();
require_once __DIR__ . '/../connection.php';

// Debug output
error_log("Google Callback Started - Session ID: " . session_id());

if (isset($_GET['code']) && isset($_GET['state'])) {
    // Verify state parameter
    if (!isset($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
        error_log("State mismatch - Session: " . ($_SESSION['oauth_state'] ?? 'NOT SET') . " vs GET: " . $_GET['state']);
        header('Location: ../register.php?error=Invalid state parameter');
        exit();
    }

    $client_id = '595063163129-e0m2lklpjea7qs83hn1kulor0tcorvf1.apps.googleusercontent.com';
    $client_secret = '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';
    $redirect_uri = 'http://localhost:3000/actions/google_callback.php';
    $code = $_GET['code'];

    // Exchange authorization code for access token
    $token_url = "https://oauth2.googleapis.com/token";
    $token_data = [
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'code' => $code,
        'grant_type' => 'authorization_code',
        'redirect_uri' => $redirect_uri
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $token_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $token_response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        error_log("Token exchange failed: " . $token_response);
        $return_to = $_SESSION['return_to'] ?? '../register.php';
        header('Location: ' . $return_to . '?error=Google authentication failed');
        exit();
    }

    $token_data = json_decode($token_response, true);

    if (isset($token_data['access_token'])) {
        // Get user info from Google
        $user_info_url = "https://www.googleapis.com/oauth2/v2/userinfo";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $user_info_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token_data['access_token']
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        $user_info_response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200) {
            error_log("User info failed: " . $user_info_response);
            $return_to = $_SESSION['return_to'] ?? '../register.php';
            header('Location: ' . $return_to . '?error=Failed to get user information');
            exit();
        }

        $user_info = json_decode($user_info_response, true);
        error_log("User info received: " . print_r($user_info, true));

        if (isset($user_info['email'])) {
            // Check if user exists in database by google_id or email
            $stmt = $pdo->prepare("SELECT * FROM users WHERE google_id = ? OR email = ?");
            $stmt->execute([$user_info['id'], $user_info['email']]);
            $user = $stmt->fetch();

            if ($user) {
                // Update existing user with google_id if not set
                if (empty($user['google_id'])) {
                    $update_stmt = $pdo->prepare("UPDATE users SET google_id = ?, oauth_provider = 'google' WHERE id = ?");
                    $update_stmt->execute([$user_info['id'], $user['id']]);
                }
                
                // User exists, log them in - SET ALL SESSION VARIABLES
                $_SESSION['loggedIn'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_username'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];
                
                error_log("User logged in - ID: " . $user['id'] . ", Email: " . $user['email']);
                
                // Force session write
                session_write_close();
                
                // Redirect to home page instead of return_to
                header('Location: ../home.php');
                exit();
            } else {
                // Create new user
                $name = $user_info['given_name'] ?? '';
                $last_name = $user_info['family_name'] ?? '';
                $email = $user_info['email'];
                $google_id = $user_info['id'];
                
                // Generate a username from email
                $username = explode('@', $email)[0] . '_' . substr(md5($email), 0, 6);
                
                $stmt = $pdo->prepare("INSERT INTO users (name, last_name, username, email, password, google_id, oauth_provider) VALUES (?, ?, ?, ?, ?, ?, 'google')");
                $stmt->execute([$name, $last_name, $username, $email, NULL, $google_id]);
                $new_user_id = $pdo->lastInsertId();
                
                $_SESSION['loggedIn'] = true;
                $_SESSION['user_id'] = $new_user_id;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_username'] = $username;
                $_SESSION['user_role'] = 'user';
                
                error_log("New user created - ID: " . $new_user_id . ", Email: " . $email);
                
                // Force session write
                session_write_close();
                
                // Redirect to home page instead of return_to
                header('Location: ../home.php');
                exit();
            }
        }
    }
}

// If anything fails
error_log("Google authentication completely failed");
header('Location: ../register.php?error=Google authentication failed');
exit();
?>