<?php
session_start();
require_once '../connection.php'; // adjust path if needed

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$destination_id = $data['destination_id'] ?? null;

if (!$destination_id) {
    echo json_encode(['success' => false, 'message' => 'No destination ID provided']);
    exit;
}

try {
    // Check if already in wishlist
    $stmt = $pdo->prepare("SELECT * FROM wishlist WHERE user_id = ? AND destination_id = ?");
    $stmt->execute([$_SESSION['user_id'], $destination_id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Already in wishlist']);
        exit;
    }

    // Insert into wishlist
    $stmt = $pdo->prepare("INSERT INTO wishlist (user_id, destination_id) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $destination_id]);

    echo json_encode(['success' => true, 'message' => 'Added to wishlist']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
