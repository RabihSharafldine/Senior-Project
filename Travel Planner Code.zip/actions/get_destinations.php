<?php
session_start();
header('Content-Type: application/json');
require_once '../connection.php';

try {
    $region = isset($_GET['region']) ? trim($_GET['region']) : '';
    $sort = isset($_GET['sort']) ? trim($_GET['sort']) : 'popular';
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    
    $limit = 8;
    $offset = ($page - 1) * $limit;

    $sql = "SELECT * FROM destinations WHERE 1=1";
    $params = [];

    if (!empty($region)) {
        $sql .= " AND region = ?";
        $params[] = $region;
    }

    $sql .= " ORDER BY destination_id DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $pdo->prepare($sql);
    foreach ($params as $index => $value) {
        $stmt->bindValue($index + 1, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
    }
    
    $stmt->execute();
    $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Add default ratings (since we don't have reviews table populated)
    foreach ($destinations as &$dest) {
        $dest['avg_rating'] = 4.5;
        $dest['review_count'] = rand(10, 100);
    }

    echo json_encode([
        'success' => true,
        'destinations' => $destinations,
        'hasMore' => count($destinations) === $limit
    ]);

} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
}
?>