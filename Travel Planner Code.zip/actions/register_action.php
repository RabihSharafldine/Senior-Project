<?php
require "../connection.php";

// Include PHPMailer
require_once '../PHPMailer/PHPMailer.php';
require_once '../PHPMailer/SMTP.php';
require_once '../PHPMailer/Exception.php';
require_once '../config/email_config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $name = $_POST['name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Initialize counter variable
    $counter = 1;
    $baseUsername = strtolower($name) . '_' . strtolower(substr($last_name, 0, 4));
    $username = $baseUsername;
    
    while (true) {
        $checkSql = "SELECT id FROM users WHERE username = :username";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->bindParam(':username', $username);
        $checkStmt->execute();
        
        if ($checkStmt->rowCount() === 0) {
            break;
        }
        $username = $baseUsername . $counter;
        $counter++;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../register.php?error=" . urlencode("Please enter a valid email address"));
        exit;
    }
    if(empty(trim($name)) || empty(trim($email)) || empty(trim($password))){
        header("Location: ../register.php?error=" . urlencode("Please fill in all fields"));
        exit;
    }
    
    try { 
        $checkSql = "SELECT * FROM users WHERE email = :email";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->bindParam(':email', $email);
        $checkStmt->execute();
        
        if($checkStmt->rowCount() > 0){
            header("Location: ../register.php?error=" . urlencode("Email already exists"));
            exit;
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // List of admin emails that don't require verification
            $adminEmails = [
                'abouelezz_ghaith@travelplanner.com',
                'sharafeldein_rabih@travelplanner.com'
            ];
            
            // Check if this is an admin email (no verification needed)
            $isAdminEmail = in_array(strtolower($email), $adminEmails);
            
            // Generate email verification token only if needed
            $email_verification_token = $isAdminEmail ? null : bin2hex(random_bytes(32));
            $email_verified = $isAdminEmail ? 1 : 0; // Auto-verify admin emails
            
            $sql = "INSERT INTO users (name, last_name, username, email, password, email_verification_token, email_verified) 
                    VALUES (:name, :last_name, :username, :email, :password, :email_verification_token, :email_verified)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':email_verification_token', $email_verification_token);
            $stmt->bindParam(':email_verified', $email_verified);
            $stmt->execute();
            
            // Get the new user ID
            $user_id = $pdo->lastInsertId();
            
            // Send welcome email (with verification link only for non-admin emails)
            if ($isAdminEmail) {
                // For admin emails, send welcome email without verification
                if (sendAdminWelcomeEmail($email, $name)) {
                    header("Location: ../login.php?success=" . urlencode("Admin account created successfully! You can login immediately."));
                } else {
                    header("Location: ../login.php?success=" . urlencode("Admin account created successfully! Welcome email could not be sent, but you can login."));
                }
            } else {
                // For regular users, send verification email
                if (sendWelcomeEmail($email, $name, $email_verification_token)) {
                    header("Location: ../login.php?success=" . urlencode("Registration successful! Please check your email to verify your account."));
                } else {
                    header("Location: ../login.php?success=" . urlencode("Registration successful! Welcome email could not be sent, but you can still login."));
                }
            }
            exit;
        }
    } catch(PDOException $exc) {
        header("Location: ../register.php?error=" . urlencode("Registration failed. Please try again."));
        exit;
    }
} else {
    header("Location: ../register.php");
    exit;
}

function sendWelcomeEmail($user_email, $user_name, $verification_token) {
    try {
        $mail = new PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = SMTP_AUTH;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = SMTP_PORT;
        
        // SSL Bypass for XAMPP
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($user_email, $user_name);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to TravelPlanner - Verify Your Email';
        
        $verification_link = "http://localhost:3000/verify-email.php?token=" . $verification_token;
        
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>TravelPlanner</h1>
                    <h2>Welcome to Your Travel Adventure!</h2>
                </div>
                <div class='content'>
                    <h3>Hello " . htmlspecialchars($user_name) . ",</h3>
                    <p>Welcome to TravelPlanner! We're excited to have you join our community of global explorers.</p>
                    <p>To get started, please verify your email address by clicking the button below:</p>
                    
                    <div style='text-align: center;'>
                        <a href='$verification_link' class='button'>Verify Email Address</a>
                    </div>
                    
                    <p>If the button doesn't work, copy and paste this link into your browser:</p>
                    <p style='word-break: break-all; background: #eee; padding: 10px; border-radius: 5px;'>$verification_link</p>
                    
                    <p><strong>What's next?</strong></p>
                    <ul>
                        <li>Plan your first trip</li>
                        <li>Discover amazing destinations</li>
                        <li>Connect with fellow travelers</li>
                        <li>Get exclusive travel deals</li>
                    </ul>
                    
                    <div class='footer'>
                        <p>Happy travels,<br>The TravelPlanner Team</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Welcome to TravelPlanner!\n\nHello $user_name,\n\nWelcome to TravelPlanner! Please verify your email by clicking: $verification_link\n\nWe're excited to help you plan your next adventure!\n\nHappy travels,\nThe TravelPlanner Team";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Welcome email error: " . $mail->ErrorInfo);
        return false;
    }
}

function sendAdminWelcomeEmail($user_email, $user_name) {
    try {
        $mail = new PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = SMTP_AUTH;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port       = SMTP_PORT;
        
        // SSL Bypass for XAMPP
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($user_email, $user_name);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to TravelPlanner - Admin Account Created';
        
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .admin-badge { background: #e74c3c; color: white; padding: 5px 10px; border-radius: 15px; font-size: 12px; margin-left: 10px; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>TravelPlanner</h1>
                    <h2>Welcome to Your Travel Adventure!</h2>
                </div>
                <div class='content'>
                    <h3>Hello " . htmlspecialchars($user_name) . " <span class='admin-badge'>ADMIN</span>,</h3>
                    <p>Welcome to TravelPlanner! Your <strong>admin account</strong> has been created successfully.</p>
                    
                    <div style='background: #e8f4fd; padding: 15px; border-radius: 8px; border-left: 4px solid #3498db; margin: 20px 0;'>
                        <p><strong>🚀 Your account is ready to use!</strong></p>
                        <p>As an admin, you have immediate access to all features without email verification.</p>
                    </div>
                    
                    <p><strong>Admin Features:</strong></p>
                    <ul>
                        <li>Full system access and management</li>
                        <li>User management capabilities</li>
                        <li>Content moderation tools</li>
                        <li>Analytics and reporting</li>
                    </ul>
                    
                    <p>You can login immediately and start exploring the admin dashboard.</p>
                    
                    <div class='footer'>
                        <p>Happy travels,<br>The TravelPlanner Team</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Welcome to TravelPlanner!\n\nHello $user_name,\n\nYour ADMIN account has been created successfully!\n\nYour account is ready to use immediately without email verification.\n\nYou have access to all admin features and can login right away.\n\nHappy travels,\nThe TravelPlanner Team";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Admin welcome email error: " . $mail->ErrorInfo);
        return false;
    }
}
?>