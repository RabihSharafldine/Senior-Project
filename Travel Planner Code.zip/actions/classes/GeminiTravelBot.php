<?php
// classes/GeminiTravelBot.php
class GeminiTravelBot {
    private $apiKey;
    private $pdo;
    
    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
        $this->connectToDatabase();
    }
    
    private function connectToDatabase() {
        try {
            $this->pdo = new PDO("mysql:host=localhost;dbname=travel planner", "root", "");
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->pdo = null;
        }
    }
    
    public function generateResponse($userInput) {
        // Clean input
        $userInput = trim($userInput);
        if (empty($userInput) || strlen($userInput) < 2) {
            return "Hello! I'm your travel assistant. What would you like to know about travel destinations?";
        }
        
        // Check for greetings
        $greetings = ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening'];
        if (in_array(strtolower($userInput), $greetings)) {
            return "Hello! I'm your travel assistant. I can help you with information about destinations worldwide. Try asking about Paris, Tokyo, Bali, or any travel topic!";
        }
        
        // Check for help
        if (strpos(strtolower($userInput), 'help') !== false) {
            return "I can help you with information about travel destinations, attractions, hotels, and activities. Try asking about a specific city like 'Paris', 'Tokyo', or 'Bali', or ask about 'beaches', 'temples', or 'museums'!";
        }
        
        // FIRST: Try database (FAST - check your excellent knowledge base)
        $dbResponse = $this->getDatabaseResponse($userInput);
        if ($dbResponse) {
            return $dbResponse;
        }
        
        // SECOND: Try Gemini AI (8 seconds max) only if database has no answer
        $aiResponse = $this->callGeminiAPI($userInput);
        
        // If AI returns a good response, use it
        if (!empty($aiResponse) && strlen($aiResponse) > 30) {
            return $aiResponse;
        }
        
        // FINAL: Show suggestions from database
        return $this->getDestinationSuggestions();
    }
    
    private function getDatabaseResponse($userInput) {
        if (!$this->pdo) {
            error_log("Database connection not available");
            return null;
        }
        
        $userInput = strtolower(trim($userInput));
        
        // DEBUG: Log what we're searching for
        error_log("DEBUG: Searching database for: " . $userInput);
        
        // METHOD 1: Check if input IS a destination name (exact match)
        $sql = "SELECT * FROM chatbot_knowledge WHERE LOWER(entity_name) = ? LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userInput]);
        $result = $stmt->fetch();
        
        if ($result) {
            error_log("DEBUG: Found exact match for: " . $userInput);
            $this->updateUsageCount($result['knowledge_id']);
            return $result['response_template'];
        }
        
        // METHOD 2: Check if input CONTAINS a destination name
        // Get all destination names and check if any are in the input
        $sql = "SELECT entity_name FROM chatbot_knowledge WHERE entity_type IN ('city', 'country')";
        $stmt = $this->pdo->query($sql);
        $destinations = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
        
        foreach ($destinations as $dest) {
            $destLower = strtolower($dest);
            if (strpos($userInput, $destLower) !== false) {
                // Found a destination name in the input
                $sql = "SELECT * FROM chatbot_knowledge WHERE LOWER(entity_name) = ? LIMIT 1";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([$destLower]);
                $result = $stmt->fetch();
                
                if ($result) {
                    error_log("DEBUG: Found '$dest' in input: " . $userInput);
                    $this->updateUsageCount($result['knowledge_id']);
                    return $result['response_template'];
                }
            }
        }
        
        // METHOD 3: Search keywords column
        $words = explode(' ', $userInput);
        foreach ($words as $word) {
            if (strlen($word) < 3) continue;
            
            $sql = "SELECT * FROM chatbot_knowledge WHERE keywords LIKE ? ORDER BY priority DESC LIMIT 1";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(['%' . $word . '%']);
            $result = $stmt->fetch();
            
            if ($result) {
                error_log("DEBUG: Found keyword match for: " . $word);
                $this->updateUsageCount($result['knowledge_id']);
                return $result['response_template'];
            }
        }
        
        // METHOD 4: Try simple LIKE search on entity_name
        $sql = "SELECT * FROM chatbot_knowledge WHERE LOWER(entity_name) LIKE ? ORDER BY priority DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['%' . $userInput . '%']);
        $result = $stmt->fetch();
        
        if ($result) {
            error_log("DEBUG: Found LIKE match for: " . $userInput);
            $this->updateUsageCount($result['knowledge_id']);
            return $result['response_template'];
        }
        
        error_log("DEBUG: No database match found for: " . $userInput);
        return null;
    }
    
    private function updateUsageCount($knowledgeId) {
        if (!$this->pdo) return;
        
        try {
            $sql = "UPDATE chatbot_knowledge SET usage_count = usage_count + 1, last_used = NOW() WHERE knowledge_id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$knowledgeId]);
        } catch (Exception $e) {
            error_log("Error updating usage count: " . $e->getMessage());
        }
    }
    
    private function callGeminiAPI($userInput) {
        // Only call Gemini if database doesn't have answer
        $apiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . $this->apiKey;
        
        $prompt = "You are a professional travel assistant. Answer this travel question: " . $userInput . 
                 "\n\nProvide helpful, accurate travel information. Keep response under 300 words. Be friendly and informative.";
        
        $data = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.7,
                'maxOutputTokens' => 500,
                'topP' => 0.8,
                'topK' => 40
            ]
        ];
        
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            error_log("CURL Error: " . $error);
            return '';
        }
        
        if ($httpCode === 200) {
            $result = json_decode($response, true);
            if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
                return trim($result['candidates'][0]['content']['parts'][0]['text']);
            }
        } else {
            error_log("Gemini API Error - HTTP Code: " . $httpCode . " Response: " . $response);
        }
        
        return '';
    }
    
    private function getDestinationSuggestions() {
        if (!$this->pdo) {
            return "I can help with travel destinations like Paris, Tokyo, Bali, London, Rome, Dubai, and many more. What specific destination interests you?";
        }
        
        try {
            // Get 6 random popular destinations
            $sql = "SELECT entity_name FROM chatbot_knowledge 
                    WHERE entity_type IN ('city', 'country') 
                    ORDER BY RAND() 
                    LIMIT 6";
            
            $stmt = $this->pdo->query($sql);
            $destinations = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
            
            if (count($destinations) > 0) {
                $destList = implode(", ", $destinations);
                return "I have information about destinations like: " . $destList . ". What specific destination interests you?";
            }
            
            return "I can help with travel destinations like Paris, Tokyo, Bali, London, Rome, Dubai, and many more. What specific destination interests you?";
        } catch (Exception $e) {
            error_log("Error getting suggestions: " . $e->getMessage());
            return "I can help with travel destinations like Paris, Tokyo, Bali, London, Rome, Dubai, and many more. What specific destination interests you?";
        }
    }
}
?>