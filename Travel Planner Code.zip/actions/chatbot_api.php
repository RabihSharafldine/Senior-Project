<?php
// actions/chatbot_api.php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 1); // Turn on for debugging

session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('POST required');
    }
    
    if (!isset($_POST['message']) || empty(trim($_POST['message']))) {
        throw new Exception('No message');
    }
    
    $userMessage = trim($_POST['message']);
    
    // Include config and chatbot class
    require_once dirname(__DIR__) . '/conf/chatbot_config.php';
    require_once dirname(__DIR__) . '/classes/GeminiTravelBot.php';
    
    if (!defined('GEMINI_API_KEY') || empty(GEMINI_API_KEY)) {
        throw new Exception('Gemini API key not set');
    }
    
    // Create chatbot instance
    $chatbot = new GeminiTravelBot(GEMINI_API_KEY);
    
    // Get response
    $botResponse = $chatbot->generateResponse($userMessage);
    
    $response['success'] = true;
    $response['message'] = $botResponse;
    
} catch (Exception $e) {
    // FIXED: success should be false on error
    $response['success'] = false;
    $response['message'] = "Hello! I'm your travel assistant. Ask me about travel destinations!";
    error_log("Chatbot API Error: " . $e->getMessage());
}

ob_end_clean();
echo json_encode($response);
?>