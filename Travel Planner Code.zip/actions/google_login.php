<?php
session_start();
require_once __DIR__ . '/../connection.php';

// Google OAuth Configuration
$client_id = '595063163129-e0m2lklpjea7qs83hn1kulor0tcorvf1.apps.googleusercontent.com';
$client_secret = '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';
$redirect_uri = 'http://localhost:3000/actions/google_callback.php';

// Store the referring page to redirect back after login
if (isset($_SERVER['HTTP_REFERER'])) {
    $_SESSION['return_to'] = $_SERVER['HTTP_REFERER'];
} else {
    $_SESSION['return_to'] = '../home.php'; // Default redirect
}

// Generate a random state parameter for security
$state = bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;

// Google OAuth URL
$auth_url = "https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query([
    'client_id' => $client_id,
    'redirect_uri' => $redirect_uri,
    'response_type' => 'code',
    'scope' => 'email profile',
    'state' => $state,
    'access_type' => 'offline',
    'prompt' => 'select_account' // Changed from 'consent' to allow existing account selection
]);

header('Location: ' . $auth_url);
exit();
?>