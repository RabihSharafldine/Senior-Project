<?php
session_start();
require "../connection.php";

// Check if user is admin
if (!isset($_SESSION['loggedIn']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'get_users':
            getUsers($pdo);
            break;
        case 'get_destinations':
            getDestinations($pdo);
            break;
        case 'get_trips':
            getTrips($pdo);
            break;
        case 'get_bundles':
            getBundles($pdo);
            break;
        case 'get_accommodations':
            getAccommodations($pdo);
            break;
        case 'get_attractions':
            getAttractions($pdo);
            break;
        case 'get_stats':
            getStats($pdo);
            break;
        case 'add_user':
            addUser($pdo);
            break;
        case 'get_user':
            getUser($pdo);
            break;
        case 'delete_user':
            deleteUser($pdo);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function getUsers($pdo) {
    $stmt = $pdo->query("SELECT id, name, email, username, role, created_at FROM users ORDER BY id");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($users);
}

function getDestinations($pdo) {
    $stmt = $pdo->query("SELECT destination_id, name, country, region FROM destinations ORDER BY destination_id");
    $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($destinations);
}

function getTrips($pdo) {
    // Implementation for getting trips
    echo json_encode([]);
}

function getBundles($pdo) {
    // Implementation for getting bundles
    echo json_encode([]);
}

function getAccommodations($pdo) {
    $stmt = $pdo->query("SELECT accommodation_id, name, country, type, price_per_night, rating FROM accommodations ORDER BY accommodation_id");
    $accommodations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($accommodations);
}

function getAttractions($pdo) {
    $stmt = $pdo->query("SELECT attraction_id, name, destination_id, type, entry_fee FROM attractions ORDER BY attraction_id");
    $attractions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($attractions);
}

function getStats($pdo) {
    $userStats = $pdo->query("SELECT COUNT(*) as total_users FROM users")->fetch();
    $tripStats = $pdo->query("SELECT COUNT(*) as total_trips FROM trip")->fetch();
    $destinationStats = $pdo->query("SELECT COUNT(*) as total_destinations FROM destinations")->fetch();
    $bundleStats = $pdo->query("SELECT COUNT(*) as bundle_trips FROM trip WHERE bundle_id IS NOT NULL")->fetch();
    
    echo json_encode([
        'total_users' => $userStats['total_users'],
        'total_trips' => $tripStats['total_trips'],
        'total_destinations' => $destinationStats['total_destinations'],
        'bundle_trips' => $bundleStats['bundle_trips']
    ]);
}

function addUser($pdo) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $name = $input['name'] ?? '';
    $email = $input['email'] ?? '';
    $username = $input['username'] ?? '';
    $role = $input['role'] ?? 'user';
    $password = password_hash($input['password'] ?? '', PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (name, email, username, password, role) VALUES (?, ?, ?, ?, ?)");
    $success = $stmt->execute([$name, $email, $username, $password, $role]);
    
    echo json_encode(['success' => $success, 'message' => $success ? 'User added successfully' : 'Failed to add user']);
}

function getUser($pdo) {
    $id = $_GET['id'] ?? 0;
    $stmt = $pdo->prepare("SELECT id, name, email, username, role FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo json_encode($user);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
}

function deleteUser($pdo) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? 0;
    
    // Prevent deleting yourself
    if ($id == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Cannot delete your own account']);
        return;
    }
    
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $success = $stmt->execute([$id]);
    
    echo json_encode(['success' => $success, 'message' => $success ? 'User deleted successfully' : 'Failed to delete user']);
}
?>