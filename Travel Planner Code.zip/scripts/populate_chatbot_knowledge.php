<?php
// scripts/populate_chatbot_knowledge.php
require_once __DIR__ . '/../connection.php';

function populateChatbotKnowledge($pdo) {
    // Get all destinations
    $stmt = $pdo->query("SELECT * FROM destinations ORDER BY name");
    $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($destinations as $destination) {
        // Get attractions for this destination
        $attractionStmt = $pdo->prepare("SELECT name FROM attractions WHERE destination_id = ? LIMIT 5");
        $attractionStmt->execute([$destination['destination_id']]);
        $attractions = $attractionStmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Get hotels for this destination
        $hotelStmt = $pdo->prepare("
            SELECT a.name FROM accommodations a
            JOIN accommodation_destinations ad ON a.accommodation_id = ad.accommodation_id
            WHERE ad.destination_id = ? LIMIT 3
        ");
        $hotelStmt->execute([$destination['destination_id']]);
        $hotels = $hotelStmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Create city entry
        $keywords = strtolower($destination['name'] . ',' . $destination['country'] . ',' . $destination['region']);
        $keywords = str_replace(' ', ',', $keywords);
        
        $responseTemplate = "{$destination['name']}, {$destination['country']} - {$destination['description']}\n\n";
        
        if (!empty($attractions)) {
            $responseTemplate .= "🏛️ Key Attractions:\n";
            foreach ($attractions as $attraction) {
                $responseTemplate .= "• {$attraction}\n";
            }
        }
        
        if (!empty($hotels)) {
            $responseTemplate .= "\n🏨 Featured Hotels:\n";
            foreach ($hotels as $hotel) {
                $responseTemplate .= "• {$hotel}\n";
            }
        }
        
        $responseTemplate .= "\nWhat would you like to know about {$destination['name']}?";
        
        // Check if entry exists
        $checkStmt = $pdo->prepare("SELECT knowledge_id FROM chatbot_knowledge WHERE entity_name = ? AND entity_type = 'city'");
        $checkStmt->execute([$destination['name']]);
        
        if (!$checkStmt->fetch()) {
            $insertStmt = $pdo->prepare("
                INSERT INTO chatbot_knowledge (entity_type, entity_name, parent_entity, keywords, response_template, data_source, priority)
                VALUES ('city', ?, ?, ?, ?, 'combined', 10)
            ");
            $insertStmt->execute([
                $destination['name'],
                $destination['country'],
                $keywords,
                $responseTemplate
            ]);
            
            echo "Added: {$destination['name']}, {$destination['country']}\n";
        }
    }
    
    echo "Chatbot knowledge populated successfully!\n";
}

populateChatbotKnowledge($pdo);
?>