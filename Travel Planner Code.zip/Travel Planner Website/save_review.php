<?php
session_start();
require "connection.php";

if (!isset($_SESSION['user_id'])) {
    die("Not logged in");
}

$user_id = $_SESSION['user_id'];

$type    = $_POST['reviewable_type'];
$title   = $_POST['title'];
$rating  = $_POST['rating'];
$comment = $_POST['comment'];

$stmt = $pdo->prepare("
    INSERT INTO reviews 
    (user_id, reviewable_type, reviewable_id, rating, title, comment, status)
    VALUES 
    (:uid, :type, NULL, :rating, :title, :comment, 'reviewed')
");

$stmt->execute([
    ':uid' => $user_id,
    ':type' => $type,
    ':rating' => $rating,
    ':title' => $title,
    ':comment' => $comment
]);

header("Location: home.php");
exit;
