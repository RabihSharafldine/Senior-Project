<?php
session_start();
require 'connection.php'; // <- this defines $pdo
// Fetch 2 latest reviews from users
$userReviewsStmt = $pdo->prepare("
    SELECT r.*, u.name, u.last_name 
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.status = 'reviewed'
    ORDER BY r.created_at DESC
    LIMIT 2
");
$userReviewsStmt->execute();
$userReviews = $userReviewsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelPlanner - Your Perfect Journey Awaits</title>
    <link rel="stylesheet" href="css/style.css">
    
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/chatbot.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Earth Background -->
    <div class="earth-background">
        <div class="earth"></div>
    </div>
    
    <?php 
    if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
        include "nav_admin.php";
    } else {
        include "nav.php";
    }
    ?>

    <main class="main-content">
        
       <section class="hero">
    <div class="hero-content">
        <h1 class="hero-title">Plan Your Perfect Adventure</h1>
        <p class="hero-subtitle">Discover amazing destinations, book accommodations, and create unforgettable memories with our all-in-one travel planner</p>
        
        <div class="hero-search">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="destinationSearch" placeholder="Search for Paris, Tokyo, Bali, London..." value="">
                <button class="btn btn-primary" id="searchButton" type="button">Explore</button>
            </div>
        </div>
    </div>
</section>
        
        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>Popular Destinations</h2>
                    <p>Explore our most loved travel spots around the world</p>
                    <a href="destinations.html" class="btn btn-outline">View All Destinations</a>
                </div>
                <div class="destinations-grid" id="featuredDestinations">
                   
                </div>
            </div>
        </section>

     
        <section class="section section-dark">
            <div class="container">
                <div class="section-header">
                    <h2>How TravelPlanner Works</h2>
                    <p>Plan your perfect trip in just a few simple steps</p>
                </div>
                <div class="steps-grid">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <i class="fas fa-map-marked-alt"></i>
                        <h3>Choose Destination</h3>
                        <p>Browse through hundreds of amazing destinations worldwide</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <i class="fas fa-hotel"></i>
                        <h3>Book Accommodation</h3>
                        <p>Select from hotels, apartments, villas, or hostels</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <i class="fas fa-bus"></i>
                        <h3>Arrange Transport</h3>
                        <p>Book flights, trains, buses, or car rentals</p>
                    </div>
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <i class="fas fa-calendar-alt"></i>
                        <h3>Add Activities</h3>
                        <p>Include events and attractions to your itinerary</p>
                    </div>
                </div>
            </div>
        </section>

       
        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>Special Offers & Bundles</h2>
                    <p>Save more with our curated travel packages</p>
                </div>
                <div class="bundles-grid" id="featuredBundles">
                   
                </div>
            </div>
        </section>

       
        <section class="section section-dark">
    <div class="container">
        <div class="section-header">
            <h2>What Travelers Say</h2>
            <p>Read experiences from our happy customers</p>
        </div>
        <div class="testimonials-grid">
            <?php foreach($userReviews as $review): ?>
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <p><?php echo htmlspecialchars($review['comment']); ?></p>
                </div>
                <div class="testimonial-author">
                    <!-- Optional: you can replace with a generic avatar if you don't have user images -->
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($review['name'] . ' ' . $review['last_name']); ?>&size=150" alt="<?php echo htmlspecialchars($review['name']); ?>">
                    <div>
                        <h4><?php echo htmlspecialchars($review['name'] . ' ' . $review['last_name']); ?></h4>
                        <span><?php echo htmlspecialchars($review['reviewable_type']); ?> Trip</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-logo">
                        <i class="fas fa-compass"></i>
                        <span>TravelPlanner</span>
                    </div>
                    <p>Your trusted partner in creating unforgettable travel experiences around the world.</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="destinations.html">Destinations</a></li>
                        <li><a href="accommodations.html">Accommodations</a></li>
                        <li><a href="transport.html">Transport</a></li>
                        <li><a href="events.html">Events</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="help.html">Help Center</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                        <li><a href="faq.html">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Newsletter</h4>
                    <p>Subscribe for travel tips and exclusive deals</p>
                    <div class="newsletter-form">
                        <input type="email" placeholder="Enter your email">
                        <button class="btn btn-primary">Subscribe</button>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 TravelPlanner. All rights reserved.</p>
            </div>
        </div>
    </footer>

<!-- Floating Chatbot Button -->
<div class="travel-chatbot-wrapper">
    <button class="travel-chat-btn" id="chatbotToggle">
        <i class="fas fa-robot"></i>
        <span class="travel-chat-pulse"></span>
    </button>
    
    <div class="travel-chat-window" id="chatbotWindow">
        <div class="travel-chat-header">
            <h3><i class="fas fa-robot"></i> Travel Assistant</h3>
            <button class="travel-chat-close" id="chatbotClose">&times;</button>
        </div>
        
        <div class="travel-chat-body" id="chatbotBody">
            <div class="travel-chat-messages">
                <div class="travel-msg bot-msg">
                    <div class="travel-msg-content">
                        Hello! I'm your AI travel assistant. How can I help you plan your trip today?
                    </div>
                    <div class="travel-msg-time">Just now</div>
                </div>
            </div>
        </div>
        
        <div class="travel-chat-input">
            <input type="text" id="chatbotInput" placeholder="Ask about destinations, hotels, or travel tips...">
            <button id="chatbotSend">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
</div>
    <script src="js/navigation.js"></script>
<script src="js/home.js"></script>
<script src="js/chatbot.js"></script>
    
    
</body>
</html>