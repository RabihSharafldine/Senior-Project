<?php
ob_clean();
header_remove();
session_start();
require 'connection.php';

/* ADMIN ONLY */
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    exit('Unauthorized');
}

/* CSV HEADERS */
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename=users_full_report_' . date('Y-m-d_H-i-s') . '.csv');

/* UTF-8 BOM FOR EXCEL */
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

/* CSV COLUMN HEADERS */
fputcsv($output, [
    'User ID',
    'First Name',
    'Last Name',
    'Email',
    'Role',
    'User Created At',

    'Trip ID',
    'From',
    'To',
    'Trip Status',
    'Trip Created At',

    'Review Title',
    'Review Comment',
    'Review Rating',
    'Review Status',
    'Review Created At',

    'Wishlist Destination',
    'Wishlist Added At'
]);

/* MAIN QUERY */
$sql = "
SELECT
    u.id AS user_id,
    u.name,
    u.last_name,
    u.email,
    u.role,
    u.created_at AS user_created,

    t.trip_id,
    t.departure,
    t.arrival,
    t.status AS trip_status,
    t.created_at AS trip_created,

    r.title AS review_title,
    r.comment AS review_comment,
    r.rating AS review_rating,
    r.status AS review_status,
    r.created_at AS review_created,

    d.name AS wishlist_destination,
    w.added_at AS wishlist_added

FROM users u
LEFT JOIN trip t ON t.user_id = u.id
LEFT JOIN reviews r ON r.user_id = u.id
LEFT JOIN wishlist w ON w.user_id = u.id
LEFT JOIN destinations d ON d.destination_id = w.destination_id

ORDER BY u.id ASC
";

$stmt = $pdo->prepare($sql);
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['user_id'],
        $row['name'],
        $row['last_name'],
        $row['email'],
        $row['role'],
        $row['user_created'] ? date('d-m-Y', strtotime($row['user_created'])) : '',

        $row['trip_id'] ?? '',
        $row['departure'] ?? '',
        $row['arrival'] ?? '',
        $row['trip_status'] ?? '',
        $row['trip_created'] ? date('d-m-Y H:i', strtotime($row['trip_created'])) : '',

        $row['review_title'] ?? '',
        $row['review_comment'] ?? '',
        $row['review_rating'] ?? '',
        $row['review_status'] ?? '',
        $row['review_created'] ? date('d-m-Y H:i', strtotime($row['review_created'])) : '',

        $row['wishlist_destination'] ?? '',
        $row['wishlist_added'] ? date('d-m-Y', strtotime($row['wishlist_added'])) : ''
    ]);
}

fclose($output);
exit;
