<?php 
session_start();
require "connection.php";
if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    header("Location: home.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - TravelPlanner</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="css/register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
     <a href="home.php" class="home-button" title="Back to Home">
        <i class="fas fa-home"></i>
    </a>
    
    <div class="background-elements">
        <div class="sun"></div>
        <div class="cloud cloud-1"></div>
        <div class="cloud cloud-2"></div>
        <div class="cloud cloud-3"></div>
    </div>

   
    <div class="floating-icon airplane">
        <i class="fas fa-plane"></i>
    </div>
    <div class="floating-icon suitcase">
        <i class="fas fa-suitcase"></i>
    </div>
    <div class="floating-icon passport">
        <i class="fas fa-passport"></i>
    </div>
    <div class="floating-icon globe">
        <i class="fas fa-globe-americas"></i>
    </div>
    <div class="floating-icon compass">
        <i class="fas fa-compass"></i>
    </div>
    <div class="floating-icon camera">
        <i class="fas fa-camera"></i>
    </div>

    <div class="auth-container">
        <div class="auth-card">
            
            <div class="auth-branding">
                <div class="brand-content">
                    <div class="brand-logo">
                        <i class="fas fa-compass"></i>
                        <span>TravelPlanner</span>
                    </div>
                    <h1>Start Your Adventure!</h1>
                    <p>Join thousands of travelers planning their perfect trips. Create memories that last a lifetime.</p>
                    
                    <div class="auth-features">
                        <div class="feature">
                            <i class="fas fa-rocket"></i>
                            <span>Plan trips in minutes</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-gem"></i>
                            <span>Exclusive travel deals</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-users"></i>
                            <span>Join travel community</span>
                        </div>
                    </div>

                    <div class="welcome-stats">
                        <div class="stat">
                            <div class="stat-number">50K+</div>
                            <div class="stat-label">Happy Travelers</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number">120+</div>
                            <div class="stat-label">Countries</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number">1M+</div>
                            <div class="stat-label">Trips Planned</div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="auth-form">
                <div class="form-header">
                    <h2>Create Your Account</h2>
                    <p>Join our community of global explorers</p>
                </div>

                <form class="auth-form-content" id="registerForm" method="POST" action="actions/register_action.php">
                    <div class="form-row">
                        <div class="input-group">
                            <label for="firstName">
                                <i class="fas fa-user"></i>
                                First Name
                            </label>
                            <input name="name" type="text" id="firstName"  required>
                            <div class="input-feedback"></div>
                        </div>
                        <div class="input-group">
                            <label for="lastName">
                                <i class="fas fa-user"></i>
                                Last Name
                            </label>
                            <input name="last_name" type="text" id="lastName"   required>
                            <div class="input-feedback"></div>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="registerEmail">
                            <i class="fas fa-envelope"></i>
                            Email Address
                        </label>
                        <input type="email" name="email" id="registerEmail" placeholder="explorer@example.com" required>
                            <div class="input-feedback"></div>
                    </div>

                    <div class="input-group">
                        <label for="registerPassword">
                            <i class="fas fa-lock"></i>
                            Password
                        </label>
                        <div class="password-input">
                            <input type="password" name="password" id="registerPassword" placeholder="Create a strong password" required>
                            <button type="button" class="toggle-password" id="toggleRegisterPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength">
                            <div class="strength-bar">
                                <div class="strength-fill" id="passwordStrength"></div>
                            </div>
                            <span class="strength-text" id="passwordStrengthText">Weak</span>
                        </div>
                        <div class="password-requirements">
                            <div class="requirement" data-requirement="length">
                                <i class="fas fa-times"></i>
                                <span>At least 8 characters</span>
                            </div>
                            <div class="requirement" data-requirement="uppercase">
                                <i class="fas fa-times"></i>
                                <span>One uppercase letter</span>
                            </div>
                            <div class="requirement" data-requirement="number">
                                <i class="fas fa-times"></i>
                                <span>One number</span>
                            </div>
                            <div class="requirement" data-requirement="special">
                                <i class="fas fa-times"></i>
                                <span>One special character</span>
                            </div>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="confirmPassword">
                            <i class="fas fa-lock"></i>
                            Confirm Password
                        </label>
                        <div class="password-input">
                            <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm your password" required>
                            <button type="button" class="toggle-password" id="toggleConfirmPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="input-feedback"></div>
                    </div>

                   <div class="form-options">
    <label class="checkbox-container">
        <input type="checkbox" id="agreeTerms" required disabled>
        <span class="checkmark"></span>
        <span class="checkbox-text">
            I agree to the 
            <a href="javascript:void(0)" class="terms-link" id="showTerms">Terms of Service and Privacy Policy</a> 
            
            <br>
            <small style="color: #666; font-style: italic;">
                (Read terms first before you can accept)
            </small>
        </span>
    </label>
    <label class="checkbox-container">
        <input type="checkbox" id="newsletter">
        <span class="checkmark"></span>
        Send me travel tips and exclusive deals
    </label>
    <div class="read-notice" id="readNotice">
        <i class="fas fa-check-circle"></i> You have read and can now accept the terms
    </div>
</div>

                    <input type="submit" class="btn btn-primary btn-auth btn-text" id="registerBtn" value="Create account">
                        
                    <div class="btn-loading">
                        <i class="fas fa-spinner fa-spin"></i>
                    </div>

                    <div class="social-login">
                        <div class="divider">
                            <span>Or sign up with</span>
                        </div>
                        
                        <div class="social-buttons">
                            <a href="actions/google_login.php" class="btn btn-social btn-google">
                                <i class="fab fa-google"></i>
                                Google
                            </a>
                        </div>
                    </div>

                    <div class="auth-switch">
                        <p>Already have an account? <a href="login.php" class="switch-link">Sign in here</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="notification success" id="successNotification" style="display: none;">
        <i class="fas fa-check-circle"></i>
        <span>Account created! Welcome to TravelPlanner!</span>
    </div>

   
    <?php if(isset($_GET['error'])): ?>
    <div class="notification error" id="errorNotification">
        <i class="fas fa-exclamation-circle"></i>
        <span><?php echo htmlspecialchars($_GET['error']); ?></span>
    </div>
    <?php endif; ?>

    <!-- Terms of Service Modal -->
    <div class="terms-modal" id="termsModal">
        <div class="terms-content">
            <button class="close-modal" id="closeModal">&times;</button>
            
            <div class="terms-header">
                <h2><i class="fas fa-file-contract"></i> Terms of Service</h2>
                <p>Last Updated: <?php echo date('F j, Y'); ?></p>
            </div>
            
            <div class="terms-body">
                <h3>1. Acceptance of Terms</h3>
                <p>Welcome to TravelPlanner! By accessing or using our services, you agree to be bound by these Terms of Service. If you disagree with any part of the terms, you may not access the service.</p>
                
                <h3>2. User Accounts</h3>
                <p>You are responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account.</p>
                
                <h3>3. Travel Planning Services</h3>
                <p>TravelPlanner provides planning tools and recommendations. We are not a travel agency and do not book flights, hotels, or other travel services directly.</p>
                
                <h3>4. User Content</h3>
                <p>You retain ownership of any content you submit, but grant us a license to use, modify, and display it in connection with our services.</p>
                
                <h3>5. Limitation of Liability</h3>
                <p>TravelPlanner shall not be liable for any indirect, incidental, special, consequential or punitive damages resulting from your use of or inability to use the service.</p>
                
                <h3>6. Modifications to Service</h3>
                <p>We reserve the right to modify or discontinue, temporarily or permanently, the service with or without notice.</p>
                
                <h3>7. Governing Law</h3>
                <p>These terms shall be governed by the laws of [Your Country/State] without regard to its conflict of law provisions.</p>
                
                <h3>8. Contact Information</h3>
                <p>Questions about the Terms of Service should be sent to us at legal@travelplanner.com.</p>
            </div>
            
            <div class="terms-footer">
                <button class="btn-terms btn-decline" id="declineTerms">
                    <i class="fas fa-times"></i> I Decline
                </button>
                <button class="btn-terms btn-agree" id="acceptTerms">
                    <i class="fas fa-check"></i> I Accept Terms
                </button>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Terms Modal Functionality
        document.addEventListener('DOMContentLoaded', function() {
            const termsModal = document.getElementById('termsModal');
            const showTermsLink = document.getElementById('showTerms');
            const closeModalBtn = document.getElementById('closeModal');
            const acceptTermsBtn = document.getElementById('acceptTerms');
            const declineTermsBtn = document.getElementById('declineTerms');
            const agreeTermsCheckbox = document.getElementById('agreeTerms');
            const readNotice = document.getElementById('readNotice');
            const termsContent = document.querySelector('.terms-content');
            let userScrolledToBottom = false;
            
            // Show terms modal when Terms link is clicked
            if (showTermsLink) {
                showTermsLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    termsModal.style.display = 'flex';
                    // Reset scroll state
                    userScrolledToBottom = false;
                    if (termsContent) {
                        termsContent.scrollTop = 0;
                    }
                });
            }
            
            // Track scrolling to detect if user read the terms
            if (termsContent) {
                termsContent.addEventListener('scroll', function() {
                    const scrollPercentage = (this.scrollTop + this.clientHeight) / this.scrollHeight * 100;
                    
                    if (scrollPercentage > 95) { // User scrolled to bottom
                        if (!userScrolledToBottom) {
                            userScrolledToBottom = true;
                            if (acceptTermsBtn) {
                                acceptTermsBtn.disabled = false;
                                acceptTermsBtn.innerHTML = '<i class="fas fa-check"></i> I Accept Terms';
                            }
                        }
                    }
                });
            }
            
            // Close modal when X is clicked
            if (closeModalBtn) {
                closeModalBtn.addEventListener('click', function() {
                    termsModal.style.display = 'none';
                    // Don't enable checkbox if user closed without reading
                    if (!userScrolledToBottom) {
                        if (agreeTermsCheckbox) {
                            agreeTermsCheckbox.checked = false;
                            agreeTermsCheckbox.disabled = true;
                        }
                        if (readNotice) {
                            readNotice.style.display = 'none';
                        }
                    }
                });
            }
            
            // Accept terms (only enabled after scrolling)
            if (acceptTermsBtn) {
                acceptTermsBtn.addEventListener('click', function() {
                    if (this.disabled) {
                        alert('Please read the terms by scrolling to the bottom first.');
                        return;
                    }
                    
                    if (agreeTermsCheckbox) {
                        agreeTermsCheckbox.disabled = false;
                        agreeTermsCheckbox.checked = true;
                    }
                    termsModal.style.display = 'none';
                    
                    // Show read notice
                    if (readNotice) {
                        readNotice.style.display = 'block';
                    }
                });
            }
            
            // Decline terms
            if (declineTermsBtn) {
                declineTermsBtn.addEventListener('click', function() {
                    if (agreeTermsCheckbox) {
                        agreeTermsCheckbox.checked = false;
                        agreeTermsCheckbox.disabled = true;
                    }
                    termsModal.style.display = 'none';
                    
                    if (readNotice) {
                        readNotice.style.display = 'none';
                    }
                });
            }
            
            // Close modal when clicking outside
            window.addEventListener('click', function(e) {
                if (e.target === termsModal) {
                    termsModal.style.display = 'none';
                    if (!userScrolledToBottom) {
                        if (agreeTermsCheckbox) {
                            agreeTermsCheckbox.checked = false;
                            agreeTermsCheckbox.disabled = true;
                        }
                        if (readNotice) {
                            readNotice.style.display = 'none';
                        }
                    }
                }
            });
            
            // Close modal with Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && termsModal.style.display === 'flex') {
                    termsModal.style.display = 'none';
                    if (!userScrolledToBottom) {
                        if (agreeTermsCheckbox) {
                            agreeTermsCheckbox.checked = false;
                            agreeTermsCheckbox.disabled = true;
                        }
                        if (readNotice) {
                            readNotice.style.display = 'none';
                        }
                    }
                }
            });
            
            // Prevent form submission if terms not accepted
            const registerForm = document.getElementById('registerForm');
            if (registerForm) {
                registerForm.addEventListener('submit', function(e) {
                    if (!agreeTermsCheckbox.checked || agreeTermsCheckbox.disabled) {
                        e.preventDefault();
                        alert('You must read and accept the Terms of Service before registering.');
                        termsModal.style.display = 'flex';
                    }
                });
            }
            
            const errorNotification = document.getElementById('errorNotification');
            if (errorNotification) {
                setTimeout(() => {
                    errorNotification.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>