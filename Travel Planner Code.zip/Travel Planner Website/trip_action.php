<?php
session_start();
require 'connection.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status"=>"error","message"=>"Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$trip_id = (int)($data['trip_id'] ?? 0);
$action  = $data['action'] ?? '';
$user_id = $_SESSION['user_id'];

if($trip_id <= 0){
    echo json_encode(["status"=>"error","message"=>"Invalid trip"]);
    exit;
}

if($action === "cancel"){
    $stmt = $pdo->prepare("
        UPDATE trip SET status='cancelled'
        WHERE trip_id=:id AND user_id=:uid
    ");
    $stmt->execute([':id'=>$trip_id, ':uid'=>$user_id]);

    echo json_encode(["status"=>"success","message"=>"Trip cancelled"]);
    exit;
}

if($action === "remove"){
    $stmt = $pdo->prepare("
        UPDATE trip SET visible=0
        WHERE trip_id=:id AND user_id=:uid
    ");
    $stmt->execute([':id'=>$trip_id, ':uid'=>$user_id]);

    echo json_encode(["status"=>"success","message"=>"Trip removed from page"]);
    exit;
}

echo json_encode(["status"=>"error","message"=>"Invalid action"]);
