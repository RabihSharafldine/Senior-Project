<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT trip_id, departure, arrival, adults, children, class, status, created_at
    FROM trip
    WHERE user_id = :user_id AND visible = 1
    ORDER BY created_at DESC
");
$stmt->execute([':user_id' => $user_id]);
$trips = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Trips</title>

<style>
body{
    background:#0f172a;
    font-family: Arial, sans-serif;
    margin:0;
    padding:30px;
    color:#e5e7eb;
}

.container{
    max-width:1100px;
    margin:auto;
}

h1{
    margin-bottom:25px;
}

.trip-grid{
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap:20px;
}

.trip-card{
    background:#1e293b;
    border-radius:16px;
    padding:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.4);
}

.trip-card h3{
    margin:0 0 10px;
    color:#38bdf8;
}

.trip-info{
    font-size:14px;
    margin-bottom:6px;
}

.status{
    margin-top:10px;
    font-weight:bold;
}

.status.booked{ color:#22c55e; }
.status.cancelled{ color:#f87171; }

.trip-actions{
    margin-top:15px;
}

button{
    border:none;
    padding:8px 14px;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
}

.cancel-btn{
    background:#f97316;
    color:white;
    margin-right:8px;
}

.cancel-btn:hover{ background:#ea580c; }

.remove-btn{
    background:#ef4444;
    color:white;
}

.remove-btn:hover{ background:#dc2626; }

.empty{
    background:#1e293b;
    padding:40px;
    border-radius:16px;
    text-align:center;
    font-size:18px;
}
</style>
</head>

<body>

<div class="container">
<h1>🗺️ My Planned Trips</h1>

<?php if(empty($trips)): ?>
    <div class="empty">No trips planned yet.</div>
<?php else: ?>
<div class="trip-grid">
<?php foreach($trips as $trip): ?>
    <div class="trip-card">
        <h3><?php echo htmlspecialchars($trip['departure']); ?> → <?php echo htmlspecialchars($trip['arrival']); ?></h3>

        <div class="trip-info">Adults: <?php echo $trip['adults']; ?></div>
        <div class="trip-info">Children: <?php echo $trip['children']; ?></div>
        <div class="trip-info">Class: <?php echo htmlspecialchars($trip['class']); ?></div>
        <div class="trip-info">Created: <?php echo $trip['created_at']; ?></div>

        <div class="status <?php echo $trip['status']; ?>">
            Status: <?php echo ucfirst($trip['status']); ?>
        </div>

        <div class="trip-actions">
            <?php if($trip['status'] === 'booked'): ?>
                <button class="cancel-btn" onclick="cancelTrip(<?php echo $trip['trip_id']; ?>)">
                    Cancel Trip
                </button>
            <?php endif; ?>

            <button class="remove-btn" onclick="removeTrip(<?php echo $trip['trip_id']; ?>)">
                Remove from Page
            </button>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>

<script>
function cancelTrip(id){
    if(!confirm("Cancel this trip?")) return;

    fetch("trip_action.php",{
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body:JSON.stringify({action:"cancel", trip_id:id})
    })
    .then(r=>r.json())
    .then(d=>{
        alert(d.message);
        location.reload();
    });
}

function removeTrip(id){
    if(!confirm("Remove this trip from your page?")) return;

    fetch("trip_action.php",{
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body:JSON.stringify({action:"remove", trip_id:id})
    })
    .then(r=>r.json())
    .then(d=>{
        alert(d.message);
        location.reload();
    });
}
</script>

</body>
</html>
