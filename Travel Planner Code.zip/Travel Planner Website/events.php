<?php 
session_start();
require_once 'connection.php'; // Use your existing connection file
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & Activities - TravelPlanner</title>
    
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/events.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php 
if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    include "nav_admin.php";
} else {
    include "nav.php";
}
?>

    <main class="main-content">
        <!-- Ticket Banner Section -->
        <section class="ticket-banner">
            <div class="banner-content">
                <h1 class="banner-title">
                    <i class="fas fa-ticket-alt"></i>
                    Find Tickets For Your Favorite Events
                </h1>
                <p class="banner-subtitle">
                    Book tickets for the world's most exciting experiences.
                    Click on any event below to visit official ticketing sites.
                </p>
            </div>
        </section>

        <!-- Logo Gallery Section -->
        <section class="logo-gallery-section">
            <div class="logo-gallery-container">
                <?php 
                // Fetch events from database
                try {
                    $sql = "SELECT * FROM events ORDER BY event_id";
                    $stmt = $pdo->query($sql);
                    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (empty($events)) {
                        // Fallback to hardcoded events if database is empty
                        $events = [
                            [
                                'name' => 'Formula 1',
                                'image_url' => 'images/events/f1.jpg',
                                'logo_url' => 'images/events/f1-logo.png',
                                'booking_url' => 'https://tickets.formula1.com/en'
                            ],
                            [
                                'name' => 'Football',
                                'image_url' => 'images/events/football.jpg',
                                'logo_url' => 'images/events/football-logo.jpg',
                                'booking_url' => 'https://seatpick.com/'
                            ],
                            [
                                'name' => 'UFC',
                                'image_url' => 'images/events/ufc.jpg',
                                'logo_url' => 'images/events/ufc-logo.png',
                                'booking_url' => 'https://www.ufc.com/events#events-list-upcoming'
                            ],
                            [
                                'name' => 'Concert',
                                'image_url' => 'images/events/concert.jpg',
                                'logo_url' => 'images/events/concert-logo.png',
                                'booking_url' => 'https://www.ticketmaster.com/discover/concerts'
                            ]
                        ];
                    }
                } catch (PDOException $e) {
                    // If there's a database error, use hardcoded events
                    $events = [
                        [
                            'name' => 'Formula 1',
                            'image_url' => 'images/events/f1.jpg',
                            'logo_url' => 'images/events/f1-logo.png',
                            'booking_url' => 'https://tickets.formula1.com/en'
                        ],
                        [
                            'name' => 'Football',
                            'image_url' => 'images/events/football.jpg',
                            'logo_url' => 'images/events/football-logo.jpg',
                            'booking_url' => 'https://seatpick.com/'
                        ],
                        [
                            'name' => 'UFC',
                            'image_url' => 'images/events/ufc.jpg',
                            'logo_url' => 'images/events/ufc-logo.png',
                            'booking_url' => 'https://www.ufc.com/events#events-list-upcoming'
                        ],
                        [
                            'name' => 'Concert',
                            'image_url' => 'images/events/concert.jpg',
                            'logo_url' => 'images/events/concert-logo.png',
                            'booking_url' => 'https://www.ticketmaster.com/discover/concerts'
                        ]
                    ];
                }
                
                // Display each event
                foreach ($events as $event): 
                    // Determine CSS class for logo based on event type
                    $logoClass = '';
                    if (stripos($event['name'], 'formula 1') !== false || stripos($event['name'], 'f1') !== false) {
                        $logoClass = 'f1-logo-narrow';
                        $ticketText = "Get F1 Tickets";
                    } elseif (stripos($event['name'], 'football') !== false) {
                        $logoClass = '';
                        $ticketText = "Get Football Tickets";
                    } elseif (stripos($event['name'], 'ufc') !== false) {
                        $logoClass = 'ufc-logo-narrow';
                        $ticketText = "Get UFC Tickets";
                    } elseif (stripos($event['name'], 'concert') !== false || stripos($event['name'], 'music') !== false) {
                        $logoClass = 'concert-logo-narrow';
                        $ticketText = "Get Concert Tickets";
                    } else {
                        $ticketText = "Get Tickets";
                    }
                    
                    // Use logo_url if available, otherwise construct it from name
                    $logoUrl = isset($event['logo_url']) ? $event['logo_url'] : '';
                    if (empty($logoUrl)) {
                        // Fallback logic if logo_url is not in database
                        if (stripos($event['name'], 'formula 1') !== false) {
                            $logoUrl = 'images/events/f1-logo.png';
                        } elseif (stripos($event['name'], 'football') !== false) {
                            $logoUrl = 'images/events/football-logo.jpg';
                        } elseif (stripos($event['name'], 'ufc') !== false) {
                            $logoUrl = 'images/events/ufc-logo.png';
                        } elseif (stripos($event['name'], 'concert') !== false || stripos($event['name'], 'music') !== false) {
                            $logoUrl = 'images/events/concert-logo.png';
                        }
                    }
                ?>
                <!-- Event Section -->
                <div class="category-section" onclick="window.open('<?php echo htmlspecialchars($event['booking_url']); ?>', '_blank')">
                    <div class="logo-container">
                        <img src="<?php echo htmlspecialchars($logoUrl); ?>" 
                             alt="<?php echo htmlspecialchars($event['name']); ?>" 
                             class="logo-full <?php echo $logoClass; ?>">
                    </div>
                    <div class="photo-container">
                        <img src="<?php echo htmlspecialchars($event['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($event['name']); ?>" 
                             class="photo-full">
                    </div>
                    <div class="ticket-overlay">
                        <span class="ticket-text"><?php echo $ticketText; ?></span>
                        <i class="fas fa-external-link-alt"></i>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <script src="js/data.js"></script>
    <script src="js/navigation.js"></script>
   
</body>
</html>