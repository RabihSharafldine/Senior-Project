<?php
session_start();
require 'connection.php';

// ✅ Return JSON only
header('Content-Type: application/json');
ini_set('display_errors', 0); // hide PHP warnings/notices that break JSON

// Check if user is logged in
if(!isset($_SESSION['user_id'])){
    echo json_encode(['status'=>'error','message'=>'User not logged in']);
    exit;
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if(!$data){
    echo json_encode(['status'=>'error','message'=>'No valid JSON received']);
    exit;
}

// Get user id from session
$user_id = (int)$_SESSION['user_id'];

$departure = $data['departure'] ?? '';
$arrival = $data['arrival'] ?? '';
$adults = (int)($data['adults'] ?? 1);
$children = (int)($data['children'] ?? 0);
$travelClass = $data['travelClass'] ?? 'economy';

try {
    $stmt = $pdo->prepare("
        INSERT INTO trip 
        (user_id, status, created_at, departure, arrival, adults, children, class)
        VALUES 
        (:user_id, 'booked', NOW(), :departure, :arrival, :adults, :children, :class)
    ");
    $stmt->execute([
        ':user_id' => $user_id,
        ':departure' => $departure,
        ':arrival' => $arrival,
        ':adults' => $adults,
        ':children' => $children,
        ':class' => $travelClass
    ]);

    echo json_encode(['status'=>'success','message'=>'Trip saved successfully']);
} catch(PDOException $e){
    echo json_encode(['status'=>'error','message'=>'Database error: '.$e->getMessage()]);
}
