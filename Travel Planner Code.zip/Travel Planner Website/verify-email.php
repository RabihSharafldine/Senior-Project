<?php
session_start();
require_once 'connection.php';

$token = $_GET['token'] ?? '';

if (empty($token)) {
    $_SESSION['login_error1'] = "Invalid verification link.";
    header("Location: login.php");
    exit();
}

try {
    // Find user with this verification token
    $stmt = $pdo->prepare("SELECT id, email, name FROM users WHERE email_verification_token = ? AND email_verified = 0");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Verify the email
        $updateStmt = $pdo->prepare("UPDATE users SET email_verified = 1, email_verification_token = NULL WHERE id = ?");
        $updateStmt->execute([$user['id']]);
        
        $_SESSION['login_success'] = "🎉 Email verified successfully! You can now login to your account.";
        error_log("✅ Email verified for: " . $user['email']);
        
    } else {
        // Check if already verified or invalid token
        $checkStmt = $pdo->prepare("SELECT id, email_verified FROM users WHERE email_verification_token = ?");
        $checkStmt->execute([$token]);
        $checkUser = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($checkUser) {
            if ($checkUser['email_verified'] == 1) {
                $_SESSION['login_success'] = "Email already verified. You can login.";
            } else {
                $_SESSION['login_error1'] = "Invalid verification token.";
            }
        } else {
            $_SESSION['login_error1'] = "Invalid verification link.";
        }
    }
    
} catch (PDOException $e) {
    error_log("❌ Verification error: " . $e->getMessage());
    $_SESSION['login_error1'] = "Verification failed. Please try again.";
}

header("Location: login.php");
exit();
?>