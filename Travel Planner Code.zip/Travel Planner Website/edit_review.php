<?php
session_start();
require 'connection.php';

if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false, 'message'=>'Not logged in']);
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $id = $_POST['id'];
    $title = $_POST['title'];
    $comment = $_POST['comment'];
    $rating = $_POST['rating'];

    try{
        $stmt = $pdo->prepare("UPDATE reviews SET title=:title, comment=:comment, rating=:rating WHERE id=:id AND user_id=:user_id");
        $stmt->execute([
            ':title'=>$title,
            ':comment'=>$comment,
            ':rating'=>$rating,
            ':id'=>$id,
            ':user_id'=>$_SESSION['user_id']
        ]);
        echo json_encode(['success'=>true]);
    } catch(PDOException $e){
        echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
    }
}
?>
