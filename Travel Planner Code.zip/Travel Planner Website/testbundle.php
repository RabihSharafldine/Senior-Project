<?php
session_start();
require "connection.php"; // your existing connection.php

// Fetch bundles from DB
$bundles = [];
try {
    $stmt = $pdo->query("SELECT bundle_id, name, description, status, image_url, country, region, link FROM bundletrips");
    $bundles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bundle Trips</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
body { margin:0; font-family: Arial, sans-serif; background:#f2f4f8; color:#2c3e50; }
.container { max-width:1200px; margin:0 auto; padding:20px; }
.page-hero { position:relative; min-height:40vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); color:white; }
.page-hero h1 { font-size:2.5rem; text-align:center; }

.filters-section { display:flex; gap:20px; margin:30px 0; flex-wrap:wrap; }
.filter-group { display:flex; flex-direction:column; }
.filter-group label { font-weight:600; }
.filter-group select { padding:10px; border-radius:8px; border:1px solid #ccc; }

.search-bar { display:flex; gap:10px; margin-bottom:30px; }
.search-bar input { flex:1; padding:10px 15px; border-radius:8px; border:1px solid #ccc; font-size:1rem; }
.search-bar button { padding:10px 20px; border:none; border-radius:8px; background:#3498db; color:white; cursor:pointer; font-weight:600; transition:all 0.3s ease; }
.search-bar button:hover { background:#2980b9; }

.bundles-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(350px,1fr)); gap:30px; }
.bundle-card { background:white; border-radius:15px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,0.1); transition:all 0.3s ease; }
.bundle-card:hover { transform:translateY(-5px); box-shadow:0 15px 40px rgba(0,0,0,0.15); }
.bundle-image { height:200px; position:relative; overflow:hidden; }
.bundle-image img { width:100%; height:100%; object-fit:cover; transition:transform 0.3s ease; }
.bundle-card:hover .bundle-image img { transform:scale(1.05); }
.bundle-content { padding:20px; }
.bundle-content h3 { font-size:1.3rem; margin-bottom:10px; color:#2c3e50; }
.bundle-description { color:#666; font-size:0.9rem; margin-bottom:10px; line-height:1.4; }
.bundle-info { font-size:0.9rem; margin-bottom:10px; }
.bundle-info span { font-weight:600; color:#3498db; margin-right:10px; }
.bundle-actions .btn { display:inline-flex; align-items:center; gap:5px; padding:10px 20px; border:none; border-radius:8px; cursor:pointer; transition:all 0.3s ease; }
.btn-primary { background:#3498db; color:white; }
.btn-primary:hover { background:#2980b9; }

.navbar { background:rgba(255,255,255,0.95); backdrop-filter:blur(10px); padding:15px 20px; display:flex; justify-content:space-between; align-items:center; box-shadow:0 2px 20px rgba(0,0,0,0.1); position:sticky; top:0; z-index:1000; }
.nav-logo { font-size:1.5rem; font-weight:700; color:#3498db; text-decoration:none; }
.nav-menu { display:flex; gap:15px; }
.nav-menu a { text-decoration:none; color:#2c3e50; padding:8px 12px; border-radius:6px; transition:all 0.3s ease; }
.nav-menu a:hover { background:rgba(52,152,219,0.1); color:#3498db; }
</style>
</head>
<body>

<!-- NAVBAR -->
<?php
if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    echo '<div class="navbar"><a href="#" class="nav-logo"><i class="fas fa-plane"></i> Travel Planner Admin</a><div class="nav-menu"><a href="#">Dashboard</a><a href="#">Bundles</a></div></div>';
} else {
    echo '<div class="navbar"><a href="#" class="nav-logo"><i class="fas fa-plane"></i> Travel Planner</a><div class="nav-menu"><a href="#">Home</a><a href="#">Bundles</a></div></div>';
}
?>

<!-- HERO -->
<div class="page-hero">
    <h1>Explore Bundle Trips Around the World</h1>
</div>

<div class="container">

<!-- Filters -->
<div class="filters-section">
    <div class="filter-group">
        <label for="regionFilter">Region</label>
        <select id="regionFilter">
            <option value="">All Regions</option>
            <option value="Asia">Asia</option>
            <option value="Europe">Europe</option>
            <option value="North America">North America</option>
            <option value="South America">South America</option>
            <option value="Africa">Africa</option>
            <option value="Oceania">Oceania</option>
        </select>
    </div>
</div>

<!-- Search Bar under Hero -->
<div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search by name or country">
    <button id="exploreBtn">Explore</button>
</div>

<!-- Bundles Grid -->
<div id="bundlesGrid" class="bundles-grid">
<?php if(!empty($error)): ?>
    <div style="grid-column:1/-1; text-align:center; padding:2rem; color:red;"><?= $error ?></div>
<?php elseif(empty($bundles)): ?>
    <div style="grid-column:1/-1; text-align:center; padding:2rem;">No bundles found</div>
<?php else: ?>
    <?php foreach($bundles as $bundle): ?>
        <div class="bundle-card" data-region="<?= htmlspecialchars($bundle['region']) ?>" data-name="<?= htmlspecialchars($bundle['name']) ?>" data-country="<?= htmlspecialchars($bundle['country']) ?>">
            <div class="bundle-image">
                <img src="<?= htmlspecialchars($bundle['image_url']) ?>" alt="<?= htmlspecialchars($bundle['name']) ?>">
            </div>
            <div class="bundle-content">
                <h3><?= htmlspecialchars($bundle['name']) ?></h3>
                <div class="bundle-description"><?= htmlspecialchars($bundle['description']) ?></div>
                <div class="bundle-info">
                    <span><?= htmlspecialchars($bundle['country']) ?></span>
                    <span><?= htmlspecialchars($bundle['region']) ?></span>
                    <span>Status: <?= htmlspecialchars($bundle['status']) ?></span>
                </div>
                <div class="bundle-actions">
                    <button class="btn btn-primary" onclick="window.open('<?= htmlspecialchars($bundle['link']) ?>','_blank')">
                        <i class="fas fa-external-link-alt"></i> Book Now
                    </button>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>

</div>

<script>
document.addEventListener("DOMContentLoaded", () => {

    const searchInput = document.getElementById("searchInput");
    const exploreBtn  = document.getElementById("exploreBtn");
    const regionFilter = document.getElementById("regionFilter");
    const cards = document.querySelectorAll(".bundle-card");

    /* =========================
       EXPLORE BUTTON (HOLIDIFY)
       ========================= */
    exploreBtn.addEventListener("click", () => {
        const value = searchInput.value.trim().toLowerCase();

        if (!value) {
            alert("Please enter a destination");
            return;
        }

        const formatted = value.replace(/\s+/g, "-");
        const url = `https://www.holidify.com/places/${formatted}/packages.html`;
        window.open(url, "_blank");
    });

    /* =========================
       ENTER KEY SUPPORT
       ========================= */
    searchInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            exploreBtn.click();
        }
    });

    /* =========================
       REGION FILTER ONLY
       ========================= */
    regionFilter.addEventListener("change", () => {
        const selected = regionFilter.value.toLowerCase();

        cards.forEach(card => {
            const region = card.dataset.region.toLowerCase();

            if (selected === "" || region === selected) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });

});
</script>


</body>
</html>
