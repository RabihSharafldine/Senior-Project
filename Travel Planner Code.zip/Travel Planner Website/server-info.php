<?php
echo "<h2>Server Information</h2>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Script Filename: " . $_SERVER['SCRIPT_FILENAME'] . "<br>";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "Current Directory: " . getcwd() . "<br>";

echo "<h2>Testing File Access</h2>";
$test_file = 'reset-password.php';
if (file_exists($test_file)) {
    echo "✅ File exists: " . realpath($test_file) . "<br>";
    
    // Test if web server can access it
    $url = "http://localhost:3000/../reset-password.php";
    $headers = @get_headers($url);
    if ($headers && strpos($headers[0], '200')) {
        echo "✅ Web server can access the file<br>";
    } else {
        echo "❌ Web server CANNOT access the file<br>";
    }
} else {
    echo "❌ File does not exist<br>";
}
?>