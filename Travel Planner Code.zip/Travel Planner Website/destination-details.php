<?php
function getDestinationBackgroundClass($destinationName) {
    $backgroundMap = [
        'Paris' => 'background-paris',
        'Tokyo' => 'background-tokyo',
        'New York City' => 'background-new-york',
        'Bali' => 'background-bali',
        'Rome' => 'background-rome',
        'Sydney' => 'background-sydney',
        'Dubai' => 'background-dubai',
        'Barcelona' => 'background-default',
        'London' => 'background-default',
        'Santorini' => 'background-santorini',
        'Kyoto' => 'background-kyoto',
        'Rio de Janeiro' => 'background-default',
        'Cape Town' => 'background-default',
        'Amsterdam' => 'background-default',
        'Bangkok' => 'background-default',
        'Istanbul' => 'background-default',
        'Venice' => 'background-default',
        'Machu Picchu' => 'background-default',
        'Singapore' => 'background-default',
        'Prague' => 'background-default',
        'Vancouver' => 'background-default',
        'Queenstown' => 'background-default',
        'Marrakech' => 'background-default',
        'Seoul' => 'background-default',
        'Hawaii' => 'background-bali'
    ];
    
    return $backgroundMap[$destinationName] ?? 'background-default';
}
?>
<?php
session_start();
require_once 'connection.php';

$destination_id = $_GET['id'] ?? null;

if (!$destination_id) {
    header('Location: destinations.php');
    exit;
}

try {
    // Get destination details
    $stmt = $pdo->prepare("SELECT * FROM destinations WHERE destination_id = ?");
    $stmt->execute([$destination_id]);
    $destination = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$destination) {
        header('Location: destinations.php');
        exit;
    }

    // Get accommodations count for this destination
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM accommodations a
        JOIN accommodation_destinations ad ON a.accommodation_id = ad.accommodation_id
        WHERE ad.destination_id = ?
    ");
    $stmt->execute([$destination_id]);
    $accommodation_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    // Get special places/attractions for this destination
    $stmt = $pdo->prepare("
        SELECT * FROM attractions 
        WHERE destination_id = ? 
        ORDER BY attraction_id ASC
    ");
    $stmt->execute([$destination_id]);
    $attractions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Error loading destination: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($destination['name']); ?> - TravelPlanner</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/destination-details.css">
    <link rel="stylesheet" href="css/animated-backgrounds.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
        <div class="animated-background <?php echo getDestinationBackgroundClass($destination['name']); ?>"></div>
    <?php 
    if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
        include "nav_admin.php";
    } else {
        include "nav.php";
    }
   
    ?>

    <main class="main-content">
        <section class="destination-hero">
            <div class="hero-image">
                <img src="<?php echo htmlspecialchars($destination['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($destination['name']); ?>"
                     onerror="this.src='images/destinations/default.jpg'">
                <div class="hero-overlay">
                    <div class="container">
                        <h1><?php echo htmlspecialchars($destination['name']); ?></h1>
                        <div class="destination-meta">
                            <span class="location">
                                <i class="fas fa-map-marker-alt"></i>
                                <?php echo htmlspecialchars($destination['country']); ?>
                            </span>
                            <span class="region">
                                <i class="fas fa-globe"></i>
                                <?php echo ucfirst($destination['region']); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section">
            <div class="container">
                <div class="destination-content">
                    <div class="content-main">
                        <h2>About <?php echo htmlspecialchars($destination['name']); ?></h2>
                        <p class="destination-description"><?php echo htmlspecialchars($destination['description']); ?></p>
                        
                        <div class="destination-stats">
                            <div class="stat-card">
                                <i class="fas fa-landmark"></i>
                                <div class="stat-number"><?php echo count($attractions); ?></div>
                                <div class="stat-label">Must-See Places</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-hotel"></i>
                                <div class="stat-number"><?php echo $accommodation_count; ?>+</div>
                                <div class="stat-label">Accommodations</div>
                            </div>
                            <div class="stat-card">
                                <i class="fas fa-map"></i>
                                <div class="stat-number"><?php echo ucfirst($destination['region']); ?></div>
                                <div class="stat-label">Region</div>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($attractions)): ?>
                    <section class="section">
                        <div class="container">
                            <div class="section-header">
                                <h2>Must-See Places in <?php echo htmlspecialchars($destination['name']); ?></h2>
                                <p>Discover the most iconic attractions and hidden gems</p>
                            </div>
                            
                            <div class="attractions-grid">
                                <?php foreach ($attractions as $attraction): ?>
                                <div class="attraction-card">
                                    <div class="attraction-image">
                                        <img src="<?php echo htmlspecialchars($attraction['image_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($attraction['name']); ?>"
                                             onerror="this.src='images/attractions/default-attraction.jpg'">
                                        <div class="attraction-type"><?php echo ucfirst($attraction['type']); ?></div>
                                    </div>
                                    <div class="attraction-content">
                                        <div class="attraction-header">
                                            <h3><?php echo htmlspecialchars($attraction['name']); ?></h3>
                                            <p class="attraction-description"><?php echo htmlspecialchars($attraction['description']); ?></p>
                                            
                                            <div class="attraction-details">
                                                <?php if ($attraction['entry_fee'] > 0): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-ticket-alt"></i>
                                                    <span>$<?php echo number_format($attraction['entry_fee'], 2); ?> entry fee</span>
                                                </div>
                                                <?php else: ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-ticket-alt"></i>
                                                    <span>Free entry</span>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <?php if ($attraction['opening_hours']): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-clock"></i>
                                                    <span><?php echo htmlspecialchars($attraction['opening_hours']); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <?php if ($attraction['best_time_to_visit']): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-sun"></i>
                                                    <span>Best time: <?php echo htmlspecialchars($attraction['best_time_to_visit']); ?></span>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="attraction-footer">
                                            <?php if ($attraction['entry_fee'] > 0): ?>
                                            <div class="attraction-price">$<?php echo number_format($attraction['entry_fee'], 2); ?></div>
                                            <?php else: ?>
                                            <div class="attraction-price">Free</div>
                                            <?php endif; ?>
                                            
                                            <?php if ($attraction['best_time_to_visit']): ?>
                                            <div class="attraction-best-time">
                                                <i class="fas fa-star"></i> Best: <?php echo htmlspecialchars($attraction['best_time_to_visit']); ?>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </section>
                    <?php endif; ?>

                    <!-- Centered Action Buttons at the end -->
                    <div class="action-section">
                        <div class="action-buttons">
                            <button class="btn btn-primary btn-large" onclick="chooseAccommodation(<?php echo $destination_id; ?>)">
                                <i class="fas fa-bed"></i> Find Accommodations
                            </button>
                          <button class="btn btn-outline btn-large" onclick="addToWishlist(<?php echo $destination_id; ?>)">
    <i class="fas fa-heart"></i> Save
</button>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<!-- Remove this entire footer section -->
<!--
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <div class="footer-logo">
                    <i class="fas fa-compass"></i>
                    <span>TravelPlanner</span>
                </div>
                <p>Your trusted partner in creating unforgettable travel experiences around the world.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="destinations.php">Destinations</a></li>
                    <li><a href="accommodations.php">Accommodations</a></li>
                    <li><a href="transport.php">Transport</a></li>
                    <li><a href="events.php">Events</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Support</h4>
                <ul>
                    <li><a href="help.php">Help Center</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="faq.php">FAQ</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
-->

    <script>
    function chooseAccommodation(destinationId) {
        const destinationData = {
            id: destinationId,
            name: '<?php echo addslashes($destination['name']); ?>',
            country: '<?php echo addslashes($destination['country']); ?>'
        };
        
        sessionStorage.setItem('selectedDestination', JSON.stringify(destinationData));
        window.location.href = 'accommodations.php';
    }

    function addToWishlist(destinationId) {
        if (confirm('Add this destination to your wishlist?')) {
            fetch('actions/add_to_wishlist.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ destination_id: destinationId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Destination added to wishlist!');
                } else {
                    alert('Please login to add to wishlist');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error adding to wishlist');
            });
        }
    }
    </script>
</body>
</html>