<?php
session_start();
require_once "connection.php";

try {
    $stmt = $pdo->query("SELECT * FROM bundletrips");
    $bundles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("DB error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Bundle Trips | TravelPlanner</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- SAME CSS AS ACCOMMODATIONS -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/components.css">
<link rel="stylesheet" href="css/accommodations.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* align search like accommodations */
.bundle-search {
    max-width: 600px;
    margin: 30px auto 0;
}
</style>
</head>

<body>

<?php 
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    include "nav_admin.php";
} else {
    include "nav.php";
}
?>

<!-- HERO -->
<section class="page-hero">
    <div class="container">
        <h1>Explore Bundle Trips Around the World</h1>
        <p>Carefully curated travel packages for unforgettable experiences</p>

        <!-- SEARCH -->
        <div class="hero-search bundle-search">
            <div class="search-box large">
                <input 
                    type="text" 
                    id="bundleSearch"
                    placeholder="Search destination (e.g. paris, tokyo)">
                <button class="btn btn-primary" onclick="searchBundle()">
                    Explore
                </button>
            </div>
        </div>
    </div>
</section>

<!-- FILTERS -->
<section class="section">
<div class="container">

<div class="filters-section">
    <div class="filter-group">
        <label>Region</label>
        <select id="regionFilter" onchange="filterRegion()">
            <option value="">All Regions</option>
            <option value="europe">Europe</option>
            <option value="asia">Asia</option>
            <option value="north america">North America</option>
            <option value="south america">South America</option>
            <option value="africa">Africa</option>
            <option value="oceania">Oceania</option>
        </select>
    </div>
</div>

<!-- GRID -->
<div class="accommodations-grid" id="bundleGrid">

<?php if (empty($bundles)): ?>
    <p>No bundles found.</p>
<?php else: ?>
<?php foreach ($bundles as $b): ?>
    <div class="accommodation-card bundle-card"
         data-region="<?= strtolower($b['region']) ?>">

        <div class="accommodation-image">
            <img src="<?= htmlspecialchars($b['image_url']) ?>" alt="">
            <div class="accommodation-type"><?= htmlspecialchars($b['country']) ?></div>
        </div>

        <div class="accommodation-content">
            <h3><?= htmlspecialchars($b['name']) ?></h3>

            <p class="accommodation-description">
                <?= htmlspecialchars(substr($b['description'], 0, 120)) ?>...
            </p>

            <div class="btn-group">
                <?php if (!empty($b['link'])): ?>
                    <a href="<?= htmlspecialchars($b['link']) ?>"
                       target="_blank"
                       class="btn btn-primary">
                        Book Now
                    </a>
                <?php endif; ?>

                <a href="bundle-details.php?id=<?= (int)$b['bundle_id'] ?>"
                   class="btn btn-outline">
                    Details
                </a>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<?php endif; ?>

</div>
</div>
</section>

<!-- JS -->
<script>
function filterRegion() {
    const region = document.getElementById('regionFilter').value.toLowerCase();
    document.querySelectorAll('.bundle-card').forEach(card => {
        card.style.display = (!region || card.dataset.region === region)
            ? 'block' : 'none';
    });
}

function searchBundle() {
    const val = document.getElementById('bundleSearch').value.trim().toLowerCase();
    if (!val) return;
    window.open(`https://www.holidify.com/places/${val}/packages.html`, '_blank');
}
</script>

</body>
</html>
