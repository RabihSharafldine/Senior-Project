<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - TravelPlanner</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
  
    <div class="background-elements">
        <div class="sun"></div>
        <div class="cloud cloud-1"></div>
        <div class="cloud cloud-2"></div>
        <div class="cloud cloud-3"></div>
    </div>

    <div class="floating-icon airplane">
        <i class="fas fa-plane"></i>
    </div>
    <div class="floating-icon suitcase">
        <i class="fas fa-suitcase"></i>
    </div>
    <div class="floating-icon passport">
        <i class="fas fa-passport"></i>
    </div>
    <div class="floating-icon globe">
        <i class="fas fa-globe-americas"></i>
    </div>

    <div class="auth-container">
        <div class="auth-card">
           
            <div class="auth-branding">
                <div class="brand-content">
                    <div class="brand-logo">
                        <i class="fas fa-compass"></i>
                        <span>TravelPlanner</span>
                    </div>
                    <h1>Reset Your Password</h1>
                    <p>Enter your email address and we'll send you a link to reset your password.</p>
                    
                    <div class="auth-features">
                        <div class="feature">
                            <i class="fas fa-envelope"></i>
                            <span>Email verification</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-shield-alt"></i>
                            <span>Secure password reset</span>
                        </div>
                        <div class="feature">
                            <i class="fas fa-clock"></i>
                            <span>Quick process</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="auth-form">
                <div class="form-header">
                    <h2>Forgot Password</h2>
                    <p>We'll send a reset link to your email</p>
                </div>

                <form class="auth-form-content" id="forgotPasswordForm" method="POST" action="actions/forgot_password_action.php">
                    <div class="input-group">
                        <label for="forgotEmail">
                            <i class="fas fa-envelope"></i>
                            Email Address
                        </label>
                        <input type="email" id="forgotEmail" name="email" placeholder="explorer@example.com" required>
                        <div class="input-feedback"></div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-auth" id="resetBtn">
                        <span class="btn-text">Send Reset Link</span>
                        <div class="btn-loading">
                            <i class="fas fa-spinner fa-spin"></i>
                        </div>
                    </button>

                    <div class="auth-switch">
                        <p>Remember your password? <a href="login.php" class="switch-link">Back to login</a></p>
                    </div>
                </form>

                <?php if(isset($_SESSION['forgot_message'])): ?>
                    <div class="alert alert-success">
                        <?php 
                        echo $_SESSION['forgot_message']; 
                        unset($_SESSION['forgot_message']);
                        ?>
                    </div>
                <?php endif; ?>

                <?php if(isset($_SESSION['forgot_error'])): ?>
                    <div class="alert alert-error">
                        <?php 
                        echo $_SESSION['forgot_error']; 
                        unset($_SESSION['forgot_error']);
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
</body>
</html>