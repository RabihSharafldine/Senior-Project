<?php
session_start();
require 'connection.php';

if (!isset($_GET['id'])) {
    header("Location: bundletrips.php");
    exit;
}

$id = (int) $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM bundletrips WHERE bundle_id = ?");
$stmt->execute([$id]);
$bundle = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$bundle) {
    echo "Bundle not found";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($bundle['name']) ?> | TravelPlanner</title>

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/components.css">
<link rel="stylesheet" href="css/accommodations.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>

<?php 
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    include "nav_admin.php";
} else {
    include "nav.php";
}
?>

<!-- HERO -->
<section class="page-hero">
    <div class="container">
        <h1><?= htmlspecialchars($bundle['name']) ?></h1>
        <p><?= htmlspecialchars($bundle['country']) ?> • <?= ucfirst(htmlspecialchars($bundle['region'])) ?></p>
    </div>
</section>

<!-- CONTENT -->
<section class="section">
<div class="container">

    <div class="details-grid">

        <!-- IMAGE -->
        <div class="details-image">
            <img src="<?= htmlspecialchars($bundle['image_url']) ?>" 
                 alt="<?= htmlspecialchars($bundle['name']) ?>">
        </div>

        <!-- INFO -->
        <div class="details-content">
            <h2>About this trip</h2>
            <p><?= nl2br(htmlspecialchars($bundle['description'])) ?></p>

            <h3>What’s Included</h3>
            <ul>
                <li>✔ Accommodation in top-rated hotels</li>
                <li>✔ Guided city tours</li>
                <li>✔ Airport transfers</li>
                <li>✔ Local experiences & activities</li>
            </ul>

            <h3>Ideal For</h3>
            <p>Couples • Families • First-time visitors • Culture lovers</p>

            <!-- ✅ FIXED LINK -->
            <?php if (!empty($bundle['link'])): ?>
                <a href="<?= htmlspecialchars($bundle['link']) ?>"
                   target="_blank"
                   class="btn btn-primary">
                    Book on Holidify
                </a>
            <?php endif; ?>

        </div>
    </div>

</div>
</section>

</body>
</html>
