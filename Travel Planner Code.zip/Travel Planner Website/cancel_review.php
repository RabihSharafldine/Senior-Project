<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not authorized']);
    exit;
}

$id = (int)$_POST['id'];

$stmt = $pdo->prepare("
    UPDATE reviews
    SET status = 'cancelled'
    WHERE id = ? AND user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);

echo json_encode(['success' => true]);
