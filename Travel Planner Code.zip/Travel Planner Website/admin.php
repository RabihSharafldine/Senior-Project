<?php
session_start();
require "connection.php";

if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_user':
                addUser($pdo);
                break;
            case 'delete_user':
                deleteUser($pdo);
                break;
            case 'add_destination':
                addDestination($pdo);
                break;
            case 'delete_destination':
                deleteDestination($pdo);
                break;
        }
    }
}

function addUser($pdo) {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = password_hash($_POST['password'] ?? 'password123', PASSWORD_DEFAULT);
    $role = $_POST['role'] ?? 'user';
    
    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, username, password, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $username, $password, $role]);
        $_SESSION['message'] = "User added successfully!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error adding user: " . $e->getMessage();
    }
}

function deleteUser($pdo) {
    $user_id = $_POST['user_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $_SESSION['message'] = "User deleted successfully!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
    }
}

function addDestination($pdo) {
    $name = $_POST['name'] ?? '';
    $country = $_POST['country'] ?? '';
    $region = $_POST['region'] ?? '';
    $description = $_POST['description'] ?? '';
    
    try {
        $stmt = $pdo->prepare("INSERT INTO destinations (name, country, region, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $country, $region, $description]);
        $_SESSION['message'] = "Destination added successfully!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error adding destination: " . $e->getMessage();
    }
}

function deleteDestination($pdo) {
    $destination_id = $_POST['destination_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM destinations WHERE destination_id = ?");
        $stmt->execute([$destination_id]);
        $_SESSION['message'] = "Destination deleted successfully!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error deleting destination: " . $e->getMessage();
    }
}

// Get data for display
try {
    $userStats = $pdo->query("SELECT 
        COUNT(*) as total_users,
        COUNT(CASE WHEN role = 'admin' THEN 1 END) as admin_users,
        COUNT(CASE WHEN role = 'user' THEN 1 END) as regular_users
        FROM users")->fetch();

    $tripStats = $pdo->query("SELECT COUNT(*) as total_trips FROM trip")->fetch();
    $destinationStats = $pdo->query("SELECT COUNT(*) as total_destinations FROM destinations")->fetch();
    
    $users = $pdo->query("SELECT id, name, email, username, role, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
    $destinations = $pdo->query("SELECT destination_id, name, country, region FROM destinations ORDER BY destination_id LIMIT 5")->fetchAll();
    
    $recentActivities = $pdo->query("SELECT 
        u.name as user_name,
        b.created_at as activity_date,
        'Trip Booking' as activity_type
        FROM trip b
        JOIN users u ON b.user_id = u.id
        ORDER BY b.created_at DESC
        LIMIT 5")->fetchAll();

} catch (PDOException $e) {
    $error = "Failed to load statistics: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - TravelPlanner</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *{
            color: black;
        }

        .btn-small {
    margin-bottom: 15px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 18px 22px;
    background-color: #4CAF50; /* green */
    color: #fff;
    font-size: 14px;
    border-radius: 6px;
    text-decoration: none;
    transition: background-color 0.2s;
}

.btn-small i {
    font-size: 16px;
}

.btn-small:hover {
    background-color: #45a049;
}
.admin-actions{
    margin-bottom: 15px;
}

        </style>
        
</head>
<body>
    <?php include "nav_admin.php"; ?>
    
    <div class="admin-container">
        <!-- Admin Header -->
        <div class="admin-header">
            <h1><i class="fas fa-crown"></i> Admin Dashboard</h1>
            <p>Manage your Travel Planner platform and database</p>
            
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon users">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $userStats['total_users'] ?? 0; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon trips">
                    <i class="fas fa-suitcase"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $tripStats['total_trips'] ?? 0; ?></div>
                    <div class="stat-label">Total Trips</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon destinations">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $destinationStats['total_destinations'] ?? 0; ?></div>
                    <div class="stat-label">Destinations</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon revenue">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo $userStats['admin_users'] ?? 0; ?></div>
                    <div class="stat-label">Admin Users</div>
                </div>
            </div>
        </div>
  <div class="admin-actions">
    <a href="generate_users_full_report.php" class="btn btn-primary">
    Download Users Full Report
</a>
</div>


        <!-- Main Content Area -->
        <div class="admin-content">
            <!-- Left Column -->
            <div class="content-column">
                <!-- Quick Actions -->
                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                    </div>
                    <div class="quick-actions-grid">
                        <button class="action-btn" onclick="openModal('userManagement')">
                            <i class="fas fa-user-cog"></i>
                            <span>Manage Users</span>
                        </button>
                        <button class="action-btn" onclick="openModal('destinationManagement')">
                            <i class="fas fa-map-marked-alt"></i>
                            <span>Manage Destinations</span>
                        </button>
                        <button class="action-btn" onclick="openModal('accommodationManagement')">
                            <i class="fas fa-hotel"></i>
                            <span>Manage Hotels</span>
                        </button>
                        <button class="action-btn" onclick="openModal('attractionManagement')">
                            <i class="fas fa-landmark"></i>
                            <span>Manage Attractions</span>
                        </button>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock"></i> Recent Activities</h3>
                    </div>
                    <div class="activities-list">
                        <?php if (!empty($recentActivities)): ?>
                            <?php foreach ($recentActivities as $activity): ?>
                                <div class="activity-item">
                                    <div class="activity-icon">
                                        <i class="fas fa-suitcase"></i>
                                    </div>
                                    <div class="activity-content">
                                        <div class="activity-text">
                                            <strong><?php echo htmlspecialchars($activity['user_name']); ?></strong> booked a trip
                                        </div>
                                        <div class="activity-time">
                                            <?php echo date('M j, g:i A', strtotime($activity['activity_date'])); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-data">No recent activities</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="content-column">
                <!-- User Management Preview -->
                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Recent Users</h3>
                        <button class="btn btn-sm" onclick="openModal('userManagement')">
                            <i class="fas fa-plus"></i> Add User
                        </button>
                    </div>
                    <div class="user-list">
                        <?php foreach ($users as $user): ?>
                        <div class="user-item">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                            </div>
                            <div class="user-info">
                                <div class="user-name"><?php echo htmlspecialchars($user['name']); ?></div>
                                <div class="user-email"><?php echo htmlspecialchars($user['email']); ?></div>
                                <div class="user-role <?php echo $user['role']; ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </div>
                            </div>
                            <div class="user-actions">
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="delete_user">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn-icon danger" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Destinations Preview -->
                <div class="admin-card">
                    <div class="card-header">
                        <h3><i class="fas fa-map-marker-alt"></i> Recent Destinations</h3>
                        <button class="btn btn-sm" onclick="openModal('destinationManagement')">
                            <i class="fas fa-plus"></i> Add Destination
                        </button>
                    </div>
                    <div class="user-list">
                        <?php foreach ($destinations as $destination): ?>
                        <div class="user-item">
                            <div class="user-avatar">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="user-info">
                                <div class="user-name"><?php echo htmlspecialchars($destination['name']); ?></div>
                                <div class="user-email"><?php echo htmlspecialchars($destination['country']); ?></div>
                                <div class="user-role">
                                    <?php echo ucfirst($destination['region']); ?>
                                </div>
                            </div>
                            <div class="user-actions">
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="delete_destination">
                                    <input type="hidden" name="destination_id" value="<?php echo $destination['destination_id']; ?>">
                                    <button type="submit" class="btn-icon danger" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Management Modal -->
    <div id="userManagement" class="modal-overlay">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-user-cog"></i> Add New User</h3>
                <button class="close-modal" onclick="closeModal('userManagement')">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_user">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="user-name">Full Name *</label>
                            <input type="text" id="user-name" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="user-email">Email *</label>
                            <input type="email" id="user-email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="user-username">Username *</label>
                            <input type="text" id="user-username" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="user-role">Role *</label>
                            <select id="user-role" name="role" class="form-control" required>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="user-password">Password *</label>
                        <input type="password" id="user-password" name="password" class="form-control" value="password123" required>
                        <small>Default password is "password123" - user should change it after login</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('userManagement')">Cancel</button>
                    <button type="submit" class="btn">Add User</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Destination Management Modal -->
    <div id="destinationManagement" class="modal-overlay">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-map-marked-alt"></i> Add New Destination</h3>
                <button class="close-modal" onclick="closeModal('destinationManagement')">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_destination">
                    <div class="form-group">
                        <label for="destination-name">Destination Name *</label>
                        <input type="text" id="destination-name" name="name" class="form-control" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="destination-country">Country *</label>
                            <input type="text" id="destination-country" name="country" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="destination-region">Region *</label>
                            <select id="destination-region" name="region" class="form-control" required>
                                <option value="asia">Asia</option>
                                <option value="europe">Europe</option>
                                <option value="north-america">North America</option>
                                <option value="south-america">South America</option>
                                <option value="africa">Africa</option>
                                <option value="oceania">Oceania</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="destination-description">Description</label>
                        <textarea id="destination-description" name="description" class="form-control" rows="4"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('destinationManagement')">Cancel</button>
                    <button type="submit" class="btn">Add Destination</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Accommodation Management Modal -->
    <div id="accommodationManagement" class="modal-overlay">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-hotel"></i> Manage Accommodations</h3>
                <button class="close-modal" onclick="closeModal('accommodationManagement')">&times;</button>
            </div>
            <div class="modal-body">
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Country</th>
                                <th>Type</th>
                                <th>Price/Night</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $accommodations = $pdo->query("SELECT accommodation_id, name, country, type, price_per_night FROM accommodations ORDER BY accommodation_id LIMIT 10")->fetchAll();
                            foreach ($accommodations as $acc):
                            ?>
                            <tr>
                                <td><?php echo $acc['accommodation_id']; ?></td>
                                <td><?php echo htmlspecialchars($acc['name']); ?></td>
                                <td><?php echo htmlspecialchars($acc['country']); ?></td>
                                <td><?php echo ucfirst($acc['type']); ?></td>
                                <td>$<?php echo $acc['price_per_night']; ?></td>
                                <td class="table-actions">
                                    <button class="btn-icon">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn-icon danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('accommodationManagement')">Close</button>
                <button type="button" class="btn">Add Accommodation</button>
            </div>
        </div>
    </div>

    <!-- Attraction Management Modal -->
    <div id="attractionManagement" class="modal-overlay">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fas fa-landmark"></i> Manage Attractions</h3>
                <button class="close-modal" onclick="closeModal('attractionManagement')">&times;</button>
            </div>
            <div class="modal-body">
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Destination</th>
                                <th>Type</th>
                                <th>Entry Fee</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $attractions = $pdo->query("SELECT a.attraction_id, a.name, a.type, a.entry_fee, d.name as destination_name 
                                FROM attractions a 
                                JOIN destinations d ON a.destination_id = d.destination_id 
                                ORDER BY a.attraction_id LIMIT 10")->fetchAll();
                            foreach ($attractions as $att):
                            ?>
                            <tr>
                                <td><?php echo $att['attraction_id']; ?></td>
                                <td><?php echo htmlspecialchars($att['name']); ?></td>
                                <td><?php echo htmlspecialchars($att['destination_name']); ?></td>
                                <td><?php echo ucfirst($att['type']); ?></td>
                                <td>$<?php echo $att['entry_fee']; ?></td>
                                <td class="table-actions">
                                    <button class="btn-icon">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn-icon danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('attractionManagement')">Close</button>
                <button type="button" class="btn">Add Attraction</button>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>