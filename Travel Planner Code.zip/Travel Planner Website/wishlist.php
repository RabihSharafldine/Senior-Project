<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch user's wishlist
$stmt = $pdo->prepare("
   SELECT w.wishlist_id, d.destination_id, d.name, d.country, d.image_url, d.region
FROM wishlist w
JOIN destinations d ON w.destination_id = d.destination_id
WHERE w.user_id = ?
ORDER BY w.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$destinations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Wishlist</title>
<link rel="stylesheet" href="css/style.css">
<style>
body {
    background: #f4f6f9;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
}

.wishlist-container {
    max-width: 1000px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.destination-card {
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    transition: transform 0.2s;
    cursor: pointer;
}

.destination-card:hover {
    transform: translateY(-5px);
}

.destination-image img {
    width: 100%;
    height: 160px;
    object-fit: cover;
}

.destination-content {
    padding: 15px;
}

.destination-content h3 {
    margin: 0 0 5px;
    font-size: 18px;
    color: #333;
}

.destination-content p {
    margin: 0;
    font-size: 14px;
    color: #555;
}

.btn-remove {
    margin-top: 10px;
    padding: 6px 12px;
    background: #e53935;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    width: 100%;
}

.btn-remove:hover {
    background: #c62828;
}
</style>
</head>
<body>

<h1>My Wishlist</h1>

<div class="wishlist-container">
    <?php if(empty($destinations)): ?>
        <p style="text-align:center; grid-column: 1/-1;">You have no saved destinations yet.</p>
    <?php else: ?>
        <?php foreach($destinations as $d): ?>
            <div class="destination-card" data-id="<?= $d['wishlist_id'] ?>" onclick="window.location.href='destinations.php?id=<?= $d['destination_id']; ?>'">
                <div class="destination-image">
                    <img src="<?= htmlspecialchars($d['image_url']); ?>" 
                         alt="<?= htmlspecialchars($d['name']); ?>" 
                         onerror="this.src='images/destinations/default.jpg'">
                </div>
                <div class="destination-content">
                    <h3><?= htmlspecialchars($d['name']); ?></h3>
                    <p><?= htmlspecialchars($d['country']); ?> | <?= ucfirst($d['region']); ?></p>
                    <button class="btn-remove" onclick="event.stopPropagation(); removeFromWishlist(<?= $d['wishlist_id']; ?>)">Remove</button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function removeFromWishlist(wishlistId) {
    if(confirm('Remove this destination from your wishlist?')) {
        fetch('actions/remove_from_wishlist.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: wishlistId})
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                document.querySelector(`[data-id="${wishlistId}"]`).remove();
            } else {
                alert('Error removing destination.');
            }
        });
    }
}
</script>

</body>
</html>
