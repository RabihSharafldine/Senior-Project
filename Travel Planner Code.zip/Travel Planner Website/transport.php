<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transport & Flights - TravelPlanner</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components.css">
    <link rel="stylesheet" href="css/transport.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php 
if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    include "nav_admin.php";
} else {
    include "nav.php";
}
?>

    <main class="main-content">


        <section class="section">
            <div class="container">
                <div class="section-header">
                    <h2>Flight Search & Booking</h2>
                    <p>Compare prices from top airlines and find the best deals</p>
                </div>

                <div class="transport-card">
                    <div class="card-header">
                        <h3><i class="fas fa-search"></i> Search Flights</h3>
                        <p>Fill in your travel details below to find available flights</p>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="from"><i class="fas fa-plane-departure"></i> From</label>
                            <input id="from" placeholder="City or airport (e.g., BEY, NYC, LON)">
                        </div>

                        <div class="form-group">
                            <label for="to"><i class="fas fa-plane-arrival"></i> To</label>
                            <input id="to" placeholder="City or airport (e.g., PAR, DXB, ROM)">
                        </div>

                        <div class="form-group">
                            <label for="departure"><i class="fas fa-calendar-alt"></i> Departure</label>
                            <input id="departure" type="date">
                        </div>

                        <div class="form-group">
                            <label for="return"><i class="fas fa-calendar-check"></i> Return (Optional)</label>
                            <input id="return" type="date">
                        </div>
                    </div>

                    <div class="passengers-section">
                        <h4><i class="fas fa-users"></i> Passengers</h4>
                        <div class="passengers">
                            <div class="passengers-row">
                                <div class="passenger-info">
                                    <i class="fas fa-user"></i>
                                    <span>Adults (12+)</span>
                                </div>
                                <div class="counter">
                                    <button onclick="changeCount('adults',-1)">−</button>
                                    <span id="adults">1</span>
                                    <button onclick="changeCount('adults',1)">+</button>
                                </div>
                            </div>

                            <div class="passengers-row">
                                <div class="passenger-info">
                                    <i class="fas fa-child"></i>
                                    <span>Children (2-11)</span>
                                </div>
                                <div class="counter">
                                    <button onclick="changeCount('children',-1)">−</button>
                                    <span id="children">0</span>
                                    <button onclick="changeCount('children',1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="class-section">
                        <h4><i class="fas fa-crown"></i> Travel Class</h4>
                        <input id="class-input" value="economy" type="hidden">
                        <div class="class-buttons">
                            <button class="class selected" data-class="economy">
                                <i class="fas fa-chair"></i>
                                <span>Economy</span>
                            </button>
                            <button class="class" data-class="premiumeconomy">
                                <i class="fas fa-chair-office"></i>
                                <span>Premium Economy</span>
                            </button>
                            <button class="class" data-class="business">
                                <i class="fas fa-briefcase"></i>
                                <span>Business</span>
                            </button>
                            <button class="class" data-class="first">
                                <i class="fas fa-gem"></i>
                                <span>First Class</span>
                            </button>
                        </div>
                    </div>

                    <div class="summary-section">
                        <button class="btn btn-outline" onclick="apply()">
                            <i class="fas fa-check-circle"></i>
                            Apply Selection
                        </button>
                        <div id="summary" class="summary-display">
                            <i class="fas fa-info-circle"></i>
                            <span>Not applied yet. Click "Apply Selection" to confirm.</span>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button class="btn btn-primary search-btn" onclick="searchFlights()">
                            <i class="fas fa-plane"></i>
                            Search Flights
                        </button>
                        <button class="btn btn-outline" onclick="clearForm()">
                            <i class="fas fa-redo"></i>
                            Clear Form
                        </button>
                    </div>
                </div>
            </div>
        </section>

       
    </main>

  
  

    <script src="js/transport.js"></script>
     
</body>
</html>