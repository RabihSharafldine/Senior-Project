<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, reviewable_type, rating, title, comment, status, created_at
    FROM reviews
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$reviews = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Reviews</title>
    <style>
        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        .reviews-container {
            max-width: 900px;
            margin: 40px auto;
        }

        .review-card {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .status.reviewed {
            background: #e6f4ea;
            color: #137333;
        }

        .status.cancelled {
            background: #fdecea;
            color: #b3261e;
        }

        .review-actions {
            margin-top: 15px;
        }

        button {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-right: 10px;
        }

        .btn-cancel {
            background: #ff9800;
            color: #fff;
        }

        .btn-delete {
            background: #e53935;
            color: #fff;
        }
    </style>
</head>
<body>

<div class="reviews-container">
    <h2>My Reviews</h2>

    <?php if (empty($reviews)): ?>
        <p>No reviews yet.</p>
    <?php endif; ?>

    <?php foreach ($reviews as $r): ?>
        <div class="review-card" data-id="<?= $r['id'] ?>">
            <div class="review-header">
                <h3><?= htmlspecialchars($r['title']) ?></h3>
                <span class="status <?= $r['status'] ?>">
                    <?= ucfirst($r['status']) ?>
                </span>
            </div>

            <p><strong>Type:</strong> <?= htmlspecialchars($r['reviewable_type']) ?></p>
            <p><?= htmlspecialchars($r['comment']) ?></p>
            <p>⭐ <?= $r['rating'] ?>/5</p>

            <div class="review-actions">
    <?php if ($r['status'] === 'reviewed'): ?>
        <button class="btn-cancel" data-id="<?= $r['id'] ?>">Cancel Review</button>
        <button class="btn-edit" data-id="<?= $r['id'] ?>">Edit</button>
        <button class="btn-save" data-id="<?= $r['id'] ?>" style="display:none;">Save</button>
    <?php endif; ?>

    <?php if ($r['status'] === 'cancelled'): ?>
        <button class="btn-delete" data-id="<?= $r['id'] ?>">Delete Review</button>
    <?php endif; ?>
</div>

        </div>
    <?php endforeach; ?>
</div>

<script>
document.addEventListener('click', function(e) {

    if (e.target.classList.contains('btn-cancel')) {
        const id = e.target.dataset.id;

        fetch('cancel_review.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'id=' + id
        })
        .then(res => res.json())
        .then(() => location.reload());
    }

    if (e.target.classList.contains('btn-delete')) {
        e.target.closest('.review-card').remove();
    }

});

document.addEventListener('click', function(e) {

    // CANCEL
    if (e.target.classList.contains('btn-cancel')) {
        const id = e.target.dataset.id;
        fetch('cancel_review.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'id=' + id
        })
        .then(res => res.json())
        .then(() => location.reload());
    }

    // DELETE
    if (e.target.classList.contains('btn-delete')) {
        e.target.closest('.review-card').remove();
    }

    // EDIT
    if (e.target.classList.contains('btn-edit')) {
        const card = e.target.closest('.review-card');
        const titleEl = card.querySelector('h3');
        const commentEl = card.querySelector('p:nth-of-type(2)'); // second <p> is comment
        const ratingEl = card.querySelector('p:nth-of-type(3)'); // third <p> is rating

        const title = titleEl.textContent;
        const comment = commentEl.textContent;
        const rating = ratingEl.textContent.replace('⭐ ','').replace('/5','');

        // Replace with inputs
        titleEl.innerHTML = `<input type="text" class="edit-title" value="${title}">`;
        commentEl.innerHTML = `<textarea class="edit-comment">${comment}</textarea>`;
        ratingEl.innerHTML = `⭐ <input type="number" class="edit-rating" min="1" max="5" value="${rating}"> /5`;

        // Show Save button, hide Edit
        card.querySelector('.btn-edit').style.display = 'none';
        card.querySelector('.btn-save').style.display = 'inline-block';
    }

    // SAVE
    if (e.target.classList.contains('btn-save')) {
        const card = e.target.closest('.review-card');
        const id = e.target.dataset.id;

        const newTitle = card.querySelector('.edit-title').value;
        const newComment = card.querySelector('.edit-comment').value;
        const newRating = card.querySelector('.edit-rating').value;

        fetch('edit_review.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `id=${id}&title=${encodeURIComponent(newTitle)}&comment=${encodeURIComponent(newComment)}&rating=${newRating}`
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                // Update card
                card.querySelector('h3').textContent = newTitle;
                card.querySelector('p:nth-of-type(2)').textContent = newComment;
                card.querySelector('p:nth-of-type(3)').textContent = `⭐ ${newRating}/5`;

                // Hide Save, show Edit
                card.querySelector('.btn-save').style.display = 'none';
                card.querySelector('.btn-edit').style.display = 'inline-block';
            } else {
                alert('Error updating review: ' + data.message);
            }
        });
    }

});

</script>

</body>
</html>
