<nav class="navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <i class="fas fa-compass"></i>
            <span>TravelPlanner</span>
        </div>
        <ul class="nav-menu">
            <li class="nav-item "><a href="home.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="destinations.php" class="nav-link">Destinations</a></li>
            <li class="nav-item"><a href="accommodations.php" class="nav-link">Stays</a></li>
            <li class="nav-item"><a href="transport.php" class="nav-link">Transport</a></li>
            <li class="nav-item"><a href="events.php" class="nav-link">Events</a></li>
            <li class="nav-item"><a href="bundletrips.php" class="nav-link">Bundle Trips</a></li>
            <!-- Small button on dashboard -->
<button id="writeReviewBtn" class="btn btn-small">
Review
</button>

        </ul>
        <div class="nav-auth">
            <?php if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true): ?>
                
                <div class="user-dropdown">
                    <button class="user-menu-btn">
                        <div class="user-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <span class="username">
                            <?php 
                            // FLEXIBLE USERNAME DISPLAY
                            if(isset($_SESSION['user_username'])) {
                                echo htmlspecialchars($_SESSION['user_username']);
                            } elseif(isset($_SESSION['user_name'])) {
                                echo htmlspecialchars($_SESSION['user_name']);
                            } else {
                                echo 'User';
                            }
                            ?>
                        </span>
                        <i class="fas fa-chevron-down dropdown-arrow"></i>
                    </button>
                    <div class="dropdown-menu">
                        <div class="dropdown-header">
                            <div class="username">
                                <?php 
                                // FLEXIBLE USERNAME DISPLAY
                                if(isset($_SESSION['user_username'])) {
                                    echo htmlspecialchars($_SESSION['user_username']);
                                } elseif(isset($_SESSION['user_name'])) {
                                    echo htmlspecialchars($_SESSION['user_name']);
                                } else {
                                    echo 'User';
                                }
                                ?>
                            </div>
                            <div class="user-email"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                        </div>
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i>
                            My Profile
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="actions/logout.php" class="dropdown-item logout">
                            <i class="fas fa-sign-out-alt"></i>
                            Logout
                        </a>
                    </div>
                </div>

                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const userDropdown = document.querySelector('.user-dropdown');
                    const userBtn = document.querySelector('.user-menu-btn');
                    const dropdownMenu = document.querySelector('.dropdown-menu');
                    
                    userBtn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const isVisible = dropdownMenu.style.display === 'block';
                        dropdownMenu.style.display = isVisible ? 'none' : 'block';
                    });
                    
                    document.addEventListener('click', function(e) {
                        if (!userDropdown.contains(e.target)) {
                            dropdownMenu.style.display = 'none';
                        }
                    });
                    
                    document.addEventListener('keydown', function(e) {
                        if (e.key === 'Escape') {
                            dropdownMenu.style.display = 'none';
                        }
                    });
                });
                </script>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline">Sign In</a>
                <a href="register.php" class="btn btn-primary">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>

    
</nav>
<body>
 <div id="reviewModal" class="review-modal">
  <div class="review-box">
    <button type="button" class="close-review">✖</button>

    <h2>Write a Review</h2>

    <form method="POST" action="save_review.php">

      <label>Type</label>
      <select name="reviewable_type" required>
        <option value="">Select type</option>
        <option value="trip">Trip</option>
        <option value="destination">Destination</option>
        <option value="stay">Stay</option>
        <option value="event">Event</option>
        <option value="bundle">Bundle</option>
      </select>

      <label>Title</label>
      <input type="text" name="title" required>

      <label>Rating</label>
      <select name="rating" required>
        <option value="5">★★★★★</option>
        <option value="4">★★★★</option>
        <option value="3">★★★</option>
        <option value="2">★★</option>
        <option value="1">★</option>
      </select>

      <label>Comment</label>
      <textarea name="comment" required></textarea>

      <div class="review-actions">
        <button type="submit" class="btn btn-primary">Add Review</button>
        <a href="my-reviews.php" class="btn btn-outline">My Reviews</a>
      </div>

    </form>
  </div>
</div>



<style>
.review-modal {
    display: none;            /* 🔴 THIS IS THE KEY */
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    color: black;
}

.review-box {
    background: #fff;
    width: 420px;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 20px 50px rgba(0,0,0,.3);
    position: relative;
}

.review-box h2 {
    text-align: center;
    margin-bottom: 15px;
}

.review-box label {
    font-weight: 600;
    margin-top: 10px;
    display: block;
}

.review-box input,
.review-box select,
.review-box textarea {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border-radius: 6px;
    border: 1px solid #ccc;
}

.review-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 15px;
}

.close-btn {
    position: absolute;
    top: 10px;
    right: 14px;
    font-size: 22px;
    cursor: pointer;
}

</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const openBtn = document.getElementById('writeReviewBtn');
    const modal = document.getElementById('reviewModal');
    const closeBtns = document.querySelectorAll('.close-review');

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            modal.style.display = 'flex';
        });
    }

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    });
});
</script>


     </body>