<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - TravelPlanner</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-branding">
                <div class="brand-content">
                    <div class="brand-logo">
                        <i class="fas fa-compass"></i>
                        <span>TravelPlanner</span>
                    </div>
                    <h1>Create New Password</h1>
                    <p>Enter your new password below.</p>
                </div>
            </div>

            <div class="auth-form">
                <div class="form-header">
                    <h2>Reset Password</h2>
                    <p>Enter your new password</p>
                </div>

                <?php if(isset($_SESSION['reset_error'])): ?>
                    <div class="alert alert-error">
                        <?php 
                        echo $_SESSION['reset_error']; 
                        unset($_SESSION['reset_error']);
                        ?>
                    </div>
                <?php endif; ?>

                <form class="auth-form-content" id="resetPasswordForm" method="POST" action="actions/reset_password_action.php">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    
                    <div class="input-group">
                        <label for="newPassword">
                            <i class="fas fa-lock"></i>
                            New Password
                        </label>
                        <div class="password-input">
                            <input type="password" name="new_password" id="newPassword" placeholder="Enter new password" required minlength="8">
                            <button type="button" class="toggle-password" id="toggleNewPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <!-- Add password strength indicator -->
                        <div class="password-strength">
                            <div class="strength-bar">
                                <div class="strength-fill" id="passwordStrength"></div>
                            </div>
                            <span class="strength-text" id="passwordStrengthText">Weak</span>
                        </div>
                        <!-- Add password requirements -->
                        <div class="password-requirements">
                            <div class="requirement" data-requirement="length">
                                <i class="fas fa-times"></i>
                                <span>At least 8 characters</span>
                            </div>
                            <div class="requirement" data-requirement="uppercase">
                                <i class="fas fa-times"></i>
                                <span>One uppercase letter</span>
                            </div>
                            <div class="requirement" data-requirement="number">
                                <i class="fas fa-times"></i>
                                <span>One number</span>
                            </div>
                            <div class="requirement" data-requirement="special">
                                <i class="fas fa-times"></i>
                                <span>One special character</span>
                            </div>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="confirmPassword">
                            <i class="fas fa-lock"></i>
                            Confirm Password
                        </label>
                        <div class="password-input">
                            <input type="password" name="confirm_password" id="confirmPassword" placeholder="Confirm new password" required minlength="8">
                            <button type="button" class="toggle-password" id="toggleConfirmPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="input-feedback" id="confirmPasswordFeedback"></div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-auth">
                        <span class="btn-text">Reset Password</span>
                    </button>

                    <div class="auth-switch">
                        <p>Remember your password? <a href="login.php" class="switch-link">Back to login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="js/auth.js"></script>
    <script>
        // Reset password specific JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            const resetPasswordForm = document.getElementById('resetPasswordForm');
            const newPassword = document.getElementById('newPassword');
            const confirmPassword = document.getElementById('confirmPassword');
            const toggleNewPassword = document.getElementById('toggleNewPassword');
            const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
            const passwordStrength = document.getElementById('passwordStrength');
            const passwordStrengthText = document.getElementById('passwordStrengthText');
            const confirmPasswordFeedback = document.getElementById('confirmPasswordFeedback');
            
            // Password requirements configuration
            const requirements = {
                length: { regex: /^.{8,}$/, element: document.querySelector('[data-requirement="length"]') },
                uppercase: { regex: /[A-Z]/, element: document.querySelector('[data-requirement="uppercase"]') },
                number: { regex: /[0-9]/, element: document.querySelector('[data-requirement="number"]') },
                special: { regex: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, element: document.querySelector('[data-requirement="special"]') }
            };

            // Password visibility toggling
            if (toggleNewPassword && newPassword) {
                toggleNewPassword.addEventListener('click', function() {
                    togglePasswordVisibility(newPassword, this);
                });
            }

            if (toggleConfirmPassword && confirmPassword) {
                toggleConfirmPassword.addEventListener('click', function() {
                    togglePasswordVisibility(confirmPassword, this);
                });
            }

            // Real-time password validation
            if (newPassword) {
                newPassword.addEventListener('input', function() {
                    validatePassword(this.value);
                    validatePasswordMatch();
                });
            }

            if (confirmPassword) {
                confirmPassword.addEventListener('input', validatePasswordMatch);
            }

            // Form submission handling
            if (resetPasswordForm) {
                resetPasswordForm.addEventListener('submit', function(e) {
                    if (!validateResetForm()) {
                        e.preventDefault();
                    }
                });
            }

            function togglePasswordVisibility(passwordField, toggleButton) {
                const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordField.setAttribute('type', type);
                
                const icon = toggleButton.querySelector('i');
                if (icon) {
                    icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
                }
            }

            function validatePassword(password) {
                if (!passwordStrength || !passwordStrengthText) return false;
                
                let strength = 0;
                let fulfilledRequirements = 0;
                const totalRequirements = Object.keys(requirements).length;

                Object.keys(requirements).forEach(key => {
                    const requirement = requirements[key];
                    if (!requirement.element) return;
                    
                    const isFulfilled = requirement.regex.test(password);
                    const icon = requirement.element.querySelector('i');
                    
                    if (isFulfilled) {
                        icon.className = 'fas fa-check';
                        icon.style.color = '#10b981';
                        requirement.element.style.color = '#10b981';
                        strength += 25;
                        fulfilledRequirements++;
                    } else {
                        icon.className = 'fas fa-times';
                        icon.style.color = '#ef4444';
                        requirement.element.style.color = '#6b7280';
                    }
                });

                updateStrengthMeter(strength, fulfilledRequirements, totalRequirements);
                return fulfilledRequirements === totalRequirements;
            }

            function updateStrengthMeter(strength, fulfilled, total) {
                if (!passwordStrength || !passwordStrengthText) return;
                
                passwordStrength.style.width = `${strength}%`;
                
                if (strength <= 25) {
                    passwordStrength.style.backgroundColor = '#ef4444';
                    passwordStrengthText.textContent = 'Weak';
                    passwordStrengthText.style.color = '#ef4444';
                } else if (strength <= 50) {
                    passwordStrength.style.backgroundColor = '#f59e0b';
                    passwordStrengthText.textContent = 'Fair';
                    passwordStrengthText.style.color = '#f59e0b';
                } else if (strength <= 75) {
                    passwordStrength.style.backgroundColor = '#3b82f6';
                    passwordStrengthText.textContent = 'Good';
                    passwordStrengthText.style.color = '#3b82f6';
                } else {
                    passwordStrength.style.backgroundColor = '#10b981';
                    passwordStrengthText.textContent = 'Strong';
                    passwordStrengthText.style.color = '#10b981';
                }
            }

            function validatePasswordMatch() {
                if (!confirmPassword) return false;
                
                const password = newPassword ? newPassword.value : '';
                const confirm = confirmPassword.value;

                if (confirm === '') {
                    confirmPasswordFeedback.textContent = '';
                    confirmPasswordFeedback.className = 'input-feedback';
                    return false;
                }

                if (password !== confirm) {
                    confirmPasswordFeedback.textContent = 'Passwords do not match';
                    confirmPasswordFeedback.className = 'input-feedback error';
                    return false;
                } else {
                    confirmPasswordFeedback.textContent = 'Passwords match!';
                    confirmPasswordFeedback.className = 'input-feedback success';
                    return true;
                }
            }

            function validateResetForm() {
                const password = newPassword ? newPassword.value : '';
                const confirm = confirmPassword ? confirmPassword.value : '';
                
                const isPasswordValid = validatePassword(password);
                const doPasswordsMatch = validatePasswordMatch();

                if (!isPasswordValid) {
                    alert('Please fulfill all password requirements');
                    return false;
                }

                if (!doPasswordsMatch) {
                    alert('Passwords do not match');
                    return false;
                }

                return true;
            }
        });
    </script>
</body>
</html>