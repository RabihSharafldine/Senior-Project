<?php
header('Content-Type: application/json');
require "connection.php";

try {
    $stmt = $pdo->query("SELECT name, description, status, image_url, country, link, region FROM bundletrips ORDER BY name");
    $bundles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'bundles' => $bundles
    ]);
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'General error: ' . $e->getMessage()
    ]);
}
?>
