<?php
echo "<h2>File Existence Check</h2>";

$files_to_check = [
    'reset-password.php',
    'reset_password.php', 
    'password-reset.php',
    'index.php'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        echo "✅ <strong>$file</strong> EXISTS in: " . realpath($file) . "<br>";
    } else {
        echo "❌ <strong>$file</strong> NOT FOUND<br>";
    }
}

echo "<h2>Current Directory:</h2>";
echo getcwd();

echo "<h2>Directory Contents:</h2>";
$files = scandir('.');
foreach ($files as $file) {
    if (strpos($file, 'reset') !== false || strpos($file, 'password') !== false) {
        echo "• $file<br>";
    }
}
?>