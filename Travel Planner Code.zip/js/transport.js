console.log("Transport.js loaded ✅");

let adults = 1;
let children = 0;
let travelClass = 'economy';

function changeCount(type, value){
    if(type==='adults'){
        adults = Math.max(1, Math.min(9, adults + value));
        document.getElementById('adults').textContent = adults;
    }
    if(type==='children'){
        children = Math.max(0, Math.min(7, children + value));
        document.getElementById('children').textContent = children;
    }
}

// Travel class selection
document.querySelectorAll('.class').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.class').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        travelClass = btn.dataset.class;
        document.getElementById('class-input').value = travelClass;
    };
});

// ✅ Apply button: save trip
function apply(){
    const summaryElement = document.getElementById('summary');

    const from = document.getElementById('from').value.trim().slice(0,3).toUpperCase();
    const to = document.getElementById('to').value.trim().slice(0,3).toUpperCase();
    const dep = document.getElementById('departure').value;
    const ret = document.getElementById('return').value || dep;

    if(!from || !to || !dep){
        summaryElement.innerHTML = `<span style="color:red;">Please fill required fields (From, To, Departure)</span>`;
        console.warn("Missing required fields:", {from,to,dep});
        return;
    }

    let text = `${adults} Adult${adults>1?'s':''}`;
    if(children>0) text += ` · ${children} Child${children>1?'ren':''}`;
    text += ` · ${travelClass==='premiumeconomy'?'Premium Economy':travelClass.charAt(0).toUpperCase()+travelClass.slice(1)}`;

    summaryElement.innerHTML = `<i class="fas fa-check-circle"></i> <span><strong>Selected:</strong> ${text}</span>`;
    summaryElement.classList.add('applied');

    // Prepare JSON
    const tripData = {
        departure: from,
        arrival: to,
        adults: adults,
        children: children,
        travelClass: travelClass
    };

    console.log("Sending JSON to save_trip.php:", tripData);

    // ✅ Save via fetch
    fetch('save_trip.php', { // <-- path relative to transport.php
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(tripData)
    })
    .then(res => res.json())
    .then(data => {
        console.log("Server response:", data);
        if(data.status==='success'){
            summaryElement.innerHTML += `<br style="color:green;">Trip saved successfully!`;
        } else {
            summaryElement.innerHTML += `<br style="color:red;">Error: ${data.message}`;
        }
    })
    .catch(err=>{
        console.error("Fetch error:", err);
        summaryElement.innerHTML += `<br style="color:red;">Fetch error, see console`;
    });
}

// Search Flights button: open Kayak (does not save)
function searchFlights(){
    const from = document.getElementById('from').value.trim().slice(0,3).toUpperCase();
    const to = document.getElementById('to').value.trim().slice(0,3).toUpperCase();
    const dep = document.getElementById('departure').value;
    const ret = document.getElementById('return').value || dep;

    if(!from || !to || !dep){
        alert('Please fill required fields: From, To, and Departure Date');
        return;
    }

    const cabinMap = {
        economy:'economy',
        premiumeconomy:'premiumeconomy',
        business:'business',
        first:'first'
    };

    let pax = `${adults}adults`;
    if(children>0) pax += `/children-${Array(children).fill(11).join('-')}`;
    const ucs = Math.random().toString(36).substring(2,8);

    const url = `https://booking.kayak.com/flights/${from}-${to}/${dep}/${ret}/${cabinMap[travelClass]}/${pax}?ucs=${ucs}&sort=bestflight_a`;
    window.open(url,'_blank');
}

// Clear form
function clearForm(){
    document.getElementById('from').value='';
    document.getElementById('to').value='';
    document.getElementById('departure').value='';
    document.getElementById('return').value='';
    adults=1; children=0; travelClass='economy';
    document.getElementById('adults').textContent=adults;
    document.getElementById('children').textContent=children;
    document.getElementById('class-input').value=travelClass;
    document.querySelectorAll('.class').forEach(b=>b.classList.remove('selected'));
    document.querySelector('.class[data-class="economy"]').classList.add('selected');
    const summaryElement = document.getElementById('summary');
    summaryElement.innerHTML = `<i class="fas fa-info-circle"></i> <span>Not applied yet. Click "Apply Selection" to confirm.</span>`;
    summaryElement.classList.remove('applied');
}

// Set minimum date to today
document.addEventListener('DOMContentLoaded', function(){
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('departure').min = today;
    document.getElementById('return').min = today;
});
