    document.addEventListener('DOMContentLoaded', function() {
        const termsModal = document.getElementById('termsModal');
        const showTermsLink = document.getElementById('showTerms');
        const closeModalBtn = document.getElementById('closeModal');
        const acceptTermsBtn = document.getElementById('acceptTerms');
        const declineTermsBtn = document.getElementById('declineTerms');
        const agreeTermsCheckbox = document.getElementById('agreeTerms');
        const readNotice = document.getElementById('readNotice');
        const termsContent = document.querySelector('.terms-content');
        let userScrolledToBottom = false;
        
        // Show terms modal when Terms link is clicked
        if (showTermsLink) {
            showTermsLink.addEventListener('click', function(e) {
                e.preventDefault();
                termsModal.style.display = 'flex';
                // Reset scroll state
                userScrolledToBottom = false;
                termsContent.scrollTop = 0;
                
                // Show scroll indicator
                showScrollIndicator();
            });
        }
        
        // Track scrolling to detect if user read the terms
        if (termsContent) {
            termsContent.addEventListener('scroll', function() {
                const scrollPercentage = (this.scrollTop + this.clientHeight) / this.scrollHeight * 100;
                
                if (scrollPercentage > 95) { // User scrolled to bottom (95% to be safe)
                    if (!userScrolledToBottom) {
                        userScrolledToBottom = true;
                        enableAcceptButton();
                        hideScrollIndicator();
                    }
                }
            });
        }
        
        function showScrollIndicator() {
            // Add scroll indicator to accept button
            if (acceptTermsBtn) {
                acceptTermsBtn.disabled = true;
                acceptTermsBtn.innerHTML = '<i class="fas fa-lock"></i> Scroll to read terms first';
                acceptTermsBtn.style.opacity = '0.6';
                acceptTermsBtn.style.cursor = 'not-allowed';
            }
            
            // Add visual indicator
            const scrollIndicator = document.createElement('div');
            scrollIndicator.className = 'scroll-indicator';
            scrollIndicator.innerHTML = `
                <div style="text-align: center; padding: 10px; background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 10px; margin: 10px 0;">
                    <i class="fas fa-arrow-down" style="animation: bounce 1s infinite; color: var(--primary);"></i>
                    <p style="margin: 5px 0; color: #666; font-size: 0.9rem;">
                        Please read the terms by scrolling to the bottom
                    </p>
                </div>
            `;
            
            const termsBody = document.querySelector('.terms-body');
            if (termsBody) {
                termsBody.appendChild(scrollIndicator);
            }
        }
        
        function hideScrollIndicator() {
            const scrollIndicator = document.querySelector('.scroll-indicator');
            if (scrollIndicator) {
                scrollIndicator.remove();
            }
        }
        
        function enableAcceptButton() {
            if (acceptTermsBtn) {
                acceptTermsBtn.disabled = false;
                acceptTermsBtn.innerHTML = '<i class="fas fa-check"></i> I Accept Terms';
                acceptTermsBtn.style.opacity = '1';
                acceptTermsBtn.style.cursor = 'pointer';
                
                // Show notification
                const acceptanceNote = document.createElement('div');
                acceptanceNote.className = 'acceptance-note';
                acceptanceNote.innerHTML = `
                    <div style="text-align: center; padding: 10px; background: linear-gradient(135deg, #d4edda, #c3e6cb); border-radius: 10px; margin: 10px 0; border: 1px solid #c3e6cb;">
                        <i class="fas fa-check-circle" style="color: var(--secondary);"></i>
                        <p style="margin: 5px 0; color: #155724; font-size: 0.9rem; font-weight: 600;">
                            Thank you for reading the terms. You can now accept them.
                        </p>
                    </div>
                `;
                
                const termsFooter = document.querySelector('.terms-footer');
                if (termsFooter) {
                    termsFooter.parentNode.insertBefore(acceptanceNote, termsFooter);
                }
            }
        }
        
        // Close modal when X is clicked
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', function() {
                termsModal.style.display = 'none';
                // Don't enable checkbox if user closed without reading
                if (!userScrolledToBottom) {
                    if (agreeTermsCheckbox) {
                        agreeTermsCheckbox.checked = false;
                        agreeTermsCheckbox.disabled = true;
                    }
                    if (readNotice) {
                        readNotice.style.display = 'none';
                    }
                }
            });
        }
        
        // Accept terms (only enabled after scrolling)
        if (acceptTermsBtn) {
            acceptTermsBtn.addEventListener('click', function() {
                if (this.disabled) {
                    alert('Please read the terms by scrolling to the bottom first.');
                    return;
                }
                
                if (agreeTermsCheckbox) {
                    agreeTermsCheckbox.disabled = false; // Enable the checkbox
                    agreeTermsCheckbox.checked = true;   // Check it
                    agreeTermsCheckbox.required = true;  // Make it required
                }
                termsModal.style.display = 'none';
                
                // Show read notice
                if (readNotice) {
                    readNotice.style.display = 'block';
                }
                
                // Show success notification
                showNotification('Terms of Service accepted successfully!', 'success');
            });
        }
        
        // Decline terms
        if (declineTermsBtn) {
            declineTermsBtn.addEventListener('click', function() {
                if (agreeTermsCheckbox) {
                    agreeTermsCheckbox.checked = false;
                    agreeTermsCheckbox.disabled = true;
                }
                termsModal.style.display = 'none';
                
                if (readNotice) {
                    readNotice.style.display = 'none';
                }
                
                showNotification('You have declined the Terms of Service.', 'error');
            });
        }
        
        // Show notification function
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 16px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                display: flex;
                align-items: center;
                gap: 10px;
                z-index: 1000;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                animation: slideInRight 0.3s ease;
                background-color: ${type === 'success' ? '#10b981' : '#ef4444'};
            `;
            
            notification.innerHTML = `
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(notification);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease forwards';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
            
            // Add CSS for slide out animation
            if (!document.querySelector('#notificationAnimations')) {
                const style = document.createElement('style');
                style.id = 'notificationAnimations';
                style.textContent = `
                    @keyframes slideOutRight {
                        from {
                            transform: translateX(0);
                            opacity: 1;
                        }
                        to {
                            transform: translateX(100%);
                            opacity: 0;
                        }
                    }
                    
                    @keyframes bounce {
                        0%, 100% { transform: translateY(0); }
                        50% { transform: translateY(-5px); }
                    }
                `;
                document.head.appendChild(style);
            }
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target === termsModal) {
                termsModal.style.display = 'none';
                // Don't enable checkbox if user closed without reading
                if (!userScrolledToBottom) {
                    if (agreeTermsCheckbox) {
                        agreeTermsCheckbox.checked = false;
                        agreeTermsCheckbox.disabled = true;
                    }
                    if (readNotice) {
                        readNotice.style.display = 'none';
                    }
                }
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && termsModal.style.display === 'flex') {
                termsModal.style.display = 'none';
                if (!userScrolledToBottom) {
                    if (agreeTermsCheckbox) {
                        agreeTermsCheckbox.checked = false;
                        agreeTermsCheckbox.disabled = true;
                    }
                    if (readNotice) {
                        readNotice.style.display = 'none';
                    }
                }
            }
        });
        
        // Prevent form submission if terms not accepted
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', function(e) {
                if (!agreeTermsCheckbox.checked || agreeTermsCheckbox.disabled) {
                    e.preventDefault();
                    showNotification('You must read and accept the Terms of Service before registering.', 'error');
                    // Automatically open terms modal
                    termsModal.style.display = 'flex';
                }
            });
        }
    });