// js/chatbot.js
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const chatbotToggle = document.getElementById('chatbotToggle');
    const chatbotWindow = document.getElementById('chatbotWindow');
    const chatbotClose = document.getElementById('chatbotClose');
    const chatbotInput = document.getElementById('chatbotInput');
    const chatbotSend = document.getElementById('chatbotSend');
    const chatMessages = document.querySelector('.travel-chat-messages');
    
    // State
    let isChatOpen = false;
    let isTyping = false;
    
    // Initialize
    initChatbot();
    
    // Event Listeners
    chatbotToggle.addEventListener('click', toggleChat);
    chatbotClose.addEventListener('click', closeChat);
    chatbotSend.addEventListener('click', sendMessage);
    
    chatbotInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Functions
    function initChatbot() {
        console.log('Travel Chatbot initialized (Gemini + Database)');
        // Clear any existing messages except first welcome
        setTimeout(() => {
            if (chatMessages && chatMessages.children.length === 1) {
                addMessage(
                    "I'm your AI travel assistant! I can help you with information about destinations worldwide. Try asking about Paris, Tokyo, Bali, or any travel topic!",
                    'bot'
                );
            }
        }, 500);
    }
    
    function toggleChat() {
        isChatOpen = !isChatOpen;
        if (isChatOpen) {
            openChat();
        } else {
            closeChat();
        }
    }
    
    function openChat() {
        if (chatbotWindow) chatbotWindow.style.display = 'block';
        if (chatbotToggle) chatbotToggle.classList.add('active');
        setTimeout(() => {
            if (chatbotInput) chatbotInput.focus();
        }, 300);
    }
    
    function closeChat() {
        if (chatbotWindow) chatbotWindow.style.display = 'none';
        if (chatbotToggle) chatbotToggle.classList.remove('active');
    }
    
    function sendMessage() {
        if (!chatbotInput || !chatMessages) return;
        
        const message = chatbotInput.value.trim();
        
        if (!message || isTyping) {
            return;
        }
        
        // Add user message
        addMessage(message, 'user');
        
        // Clear input
        chatbotInput.value = '';
        
        // Show typing indicator
        const typingIndicator = addTypingIndicator();
        isTyping = true;
        
        // Disable input
        chatbotInput.disabled = true;
        if (chatbotSend) chatbotSend.disabled = true;
        
        // Send to server
        fetch('actions/chatbot_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'message=' + encodeURIComponent(message)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove typing indicator
            if (typingIndicator && typingIndicator.parentNode) {
                typingIndicator.remove();
            }
            
            isTyping = false;
            
            if (data.success) {
                addMessage(data.message, 'bot');
            } else {
                addMessage('Sorry, I encountered an error. Please try your question again.', 'bot');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            
            if (typingIndicator && typingIndicator.parentNode) {
                typingIndicator.remove();
            }
            
            isTyping = false;
            addMessage('I can help with travel questions. What would you like to know?', 'bot');
        })
        .finally(() => {
            if (chatbotInput) {
                chatbotInput.disabled = false;
                chatbotInput.focus();
            }
            if (chatbotSend) chatbotSend.disabled = false;
            scrollToBottom();
        });
    }
    
    function addMessage(content, role) {
        if (!chatMessages) return null;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `travel-msg ${role}-msg`;
        
        const timeString = new Date().toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        let messageContent = content;
        if (role === 'bot') {
            messageContent = formatBotResponse(content);
        }
        
        messageDiv.innerHTML = `
            <div class="travel-msg-content">
                ${messageContent}
            </div>
            <div class="travel-msg-meta">
                <span class="travel-msg-time">${timeString}</span>
            </div>
        `;
        
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
        
        return messageDiv;
    }
    
    function formatBotResponse(text) {
        // Simple formatting - convert markdown-like to HTML
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n\n/g, '</p><p>')
            .replace(/\n/g, '<br>')
            .replace(/^(.+)$/gm, '<p>$1</p>');
    }
    
    function addTypingIndicator() {
        if (!chatMessages) return null;
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'travel-msg bot-msg typing';
        typingDiv.innerHTML = `
            <div class="travel-msg-content">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        
        chatMessages.appendChild(typingDiv);
        scrollToBottom();
        
        return typingDiv;
    }
    
    function scrollToBottom() {
        if (!chatMessages) return;
        
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});