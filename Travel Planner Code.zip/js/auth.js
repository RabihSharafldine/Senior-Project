// auth.js - TravelPlanner Authentication Script

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements - ONLY SELECT ELEMENTS THAT EXIST
    const registerForm = document.getElementById('registerForm');
    const loginForm = document.getElementById('loginForm');
    const registerPassword = document.getElementById('registerPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    const toggleRegisterPassword = document.getElementById('toggleRegisterPassword');
    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    const toggleLoginPassword = document.getElementById('toggleLoginPassword');
    const loginPassword = document.getElementById('loginPassword');

    // Only run register-specific code if on register page
    if (registerForm) {
        const passwordStrength = document.getElementById('passwordStrength');
        const passwordStrengthText = document.getElementById('passwordStrengthText');
        const passwordRequirements = document.querySelectorAll('.requirement');
        const registerBtn = document.getElementById('registerBtn');

        // Password requirements configuration - ONLY FOR REGISTER PAGE
        const requirements = {
            length: { regex: /^.{8,}$/, element: document.querySelector('[data-requirement="length"]') },
            uppercase: { regex: /[A-Z]/, element: document.querySelector('[data-requirement="uppercase"]') },
            number: { regex: /[0-9]/, element: document.querySelector('[data-requirement="number"]') },
            special: { regex: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, element: document.querySelector('[data-requirement="special"]') }
        };

        // Password visibility toggling - REGISTER PAGE
        if (toggleRegisterPassword && registerPassword) {
            toggleRegisterPassword.addEventListener('click', function() {
                togglePasswordVisibility(registerPassword, this);
            });
        }

        if (toggleConfirmPassword && confirmPassword) {
            toggleConfirmPassword.addEventListener('click', function() {
                togglePasswordVisibility(confirmPassword, this);
            });
        }

        // Real-time password validation - REGISTER PAGE ONLY
        if (registerPassword) {
            registerPassword.addEventListener('input', function() {
                validatePassword(this.value);
                validatePasswordMatch();
            });
        }

        if (confirmPassword) {
            confirmPassword.addEventListener('input', validatePasswordMatch);
        }

        // Form submission handling - REGISTER PAGE
        registerForm.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
            }
        });

        // Register page specific functions
        function validatePassword(password) {
            if (!passwordStrength || !passwordStrengthText) return false;
            
            let strength = 0;
            let fulfilledRequirements = 0;
            const totalRequirements = Object.keys(requirements).length;

            Object.keys(requirements).forEach(key => {
                const requirement = requirements[key];
                if (!requirement.element) return;
                
                const isFulfilled = requirement.regex.test(password);
                const icon = requirement.element.querySelector('i');
                
                if (isFulfilled) {
                    icon.className = 'fas fa-check';
                    icon.style.color = '#10b981';
                    requirement.element.style.color = '#10b981';
                    strength += 25;
                    fulfilledRequirements++;
                } else {
                    icon.className = 'fas fa-times';
                    icon.style.color = '#ef4444';
                    requirement.element.style.color = '#6b7280';
                }
            });

            updateStrengthMeter(strength, fulfilledRequirements, totalRequirements);
            return fulfilledRequirements === totalRequirements;
        }

        function updateStrengthMeter(strength, fulfilled, total) {
            if (!passwordStrength || !passwordStrengthText) return;
            
            passwordStrength.style.width = `${strength}%`;
            
            if (strength <= 25) {
                passwordStrength.style.backgroundColor = '#ef4444';
                passwordStrengthText.textContent = 'Weak';
                passwordStrengthText.style.color = '#ef4444';
            } else if (strength <= 50) {
                passwordStrength.style.backgroundColor = '#f59e0b';
                passwordStrengthText.textContent = 'Fair';
                passwordStrengthText.style.color = '#f59e0b';
            } else if (strength <= 75) {
                passwordStrength.style.backgroundColor = '#3b82f6';
                passwordStrengthText.textContent = 'Good';
                passwordStrengthText.style.color = '#3b82f6';
            } else {
                passwordStrength.style.backgroundColor = '#10b981';
                passwordStrengthText.textContent = 'Strong';
                passwordStrengthText.style.color = '#10b981';
            }
        }

        function validatePasswordMatch() {
            if (!confirmPassword) return false;
            
            const password = registerPassword ? registerPassword.value : '';
            const confirm = confirmPassword.value;
            const confirmGroup = confirmPassword.closest('.input-group');
            const feedback = confirmGroup ? confirmGroup.querySelector('.input-feedback') : null;

            if (confirm === '') {
                if (feedback) {
                    feedback.textContent = '';
                    feedback.className = 'input-feedback';
                }
                return false;
            }

            if (password !== confirm) {
                if (feedback) {
                    feedback.textContent = 'Passwords do not match';
                    feedback.className = 'input-feedback error';
                }
                return false;
            } else {
                if (feedback) {
                    feedback.textContent = 'Passwords match!';
                    feedback.className = 'input-feedback success';
                }
                return true;
            }
        }

        function validateForm() {
            const password = registerPassword ? registerPassword.value : '';
            const confirm = confirmPassword ? confirmPassword.value : '';
            const agreeTerms = document.getElementById('agreeTerms');
            
            if (!agreeTerms || !agreeTerms.checked) {
                alert('Please agree to the Terms of Service and Privacy Policy');
                return false;
            }

            const isPasswordValid = validatePassword(password);
            const doPasswordsMatch = validatePasswordMatch();

            if (!isPasswordValid) {
                alert('Please fulfill all password requirements');
                return false;
            }

            if (!doPasswordsMatch) {
                alert('Passwords do not match');
                return false;
            }

            return true;
        }
    }

    // LOGIN PAGE SPECIFIC CODE
    if (loginForm) {
        // Password visibility toggling - LOGIN PAGE
        if (toggleLoginPassword && loginPassword) {
            toggleLoginPassword.addEventListener('click', function() {
                togglePasswordVisibility(loginPassword, this);
            });
        }
    }

    // UNIVERSAL FUNCTIONS (work on both pages)
    function togglePasswordVisibility(passwordField, toggleButton) {
        if (!passwordField || !toggleButton) return;
        
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        
        const icon = toggleButton.querySelector('i');
        if (icon) {
            icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        }
    }

    // Remove social button handlers since we're using actual links
    /*
    document.querySelector('.btn-google')?.addEventListener('click', function() {
        alert('Google sign up would be implemented here');
    });
    */
});