// Simple search functionality using your database
document.addEventListener('DOMContentLoaded', function() {
    console.log('TravelPlanner Search initialized');
    
    const searchButton = document.querySelector('.hero-search .btn');
    const searchInput = document.querySelector('.hero-search input');
    
    if (searchButton && searchInput) {
        // Search on button click
        searchButton.addEventListener('click', performSearch);
        
        // Search on Enter key
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        
        console.log('Search event listeners attached');
    } else {
        console.error('Search elements not found');
    }
    
    // Load featured destinations
    loadFeaturedDestinations();
});

async function performSearch() {
    const searchInput = document.querySelector('.hero-search input');
    const searchTerm = searchInput.value.trim();
    
    if (!searchTerm) {
        alert('Please enter a destination name');
        return;
    }
    
    console.log('Searching for:', searchTerm);
    
    // Show loading
    const searchButton = document.querySelector('.hero-search .btn');
    const originalText = searchButton.innerHTML;
    searchButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    searchButton.disabled = true;
    
    try {
        const response = await fetch(`actions/search_destinations.php?q=${encodeURIComponent(searchTerm)}`);
        
        // First, check if response is OK
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Get the response as text first to see what we're getting
        const responseText = await response.text();
        console.log('Raw response:', responseText);
        
        // Try to parse as JSON
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            throw new Error('Invalid response from server. Check PHP errors.');
        }
        
        console.log('Parsed data:', data);
        
        if (data.success && data.destinations && data.destinations.length > 0) {
            // Redirect to the first matching destination
            const destination = data.destinations[0];
            console.log('Redirecting to:', destination.name);
            window.location.href = `destination-details.php?id=${destination.destination_id}`;
        } else {
            const message = data.message || `No destinations found for "${searchTerm}"`;
            alert(message + '\n\nTry: Paris, Tokyo, Bali, London, New York, etc.');
        }
    } catch (error) {
        console.error('Search error:', error);
        alert('Search failed: ' + error.message + '\n\nPlease check the browser console for details.');
    } finally {
        // Restore button
        searchButton.innerHTML = originalText;
        searchButton.disabled = false;
    }
}

async function loadFeaturedDestinations() {
    try {
        const response = await fetch('actions/get_destinations.php?page=1&limit=4');
        const data = await response.json();
        
        if (data.success && data.destinations) {
            const container = document.getElementById('featuredDestinations');
            if (container) {
                container.innerHTML = data.destinations.map(destination => `
                    <div class="destination-card">
                        <div class="destination-image">
                            <img src="${destination.image_url}" alt="${destination.name}" 
                                 onerror="this.src='images/destinations/default.jpg'">
                        </div>
                        <div class="destination-content">
                            <h3>${destination.name}</h3>
                            <div class="destination-location">
                                <i class="fas fa-map-marker-alt"></i>
                                ${destination.country}
                            </div>
                            <p class="destination-description">${destination.description ? destination.description.substring(0, 100) + '...' : 'Explore this amazing destination'}</p>
                            <button class="btn btn-primary" onclick="window.location.href='destination-details.php?id=${destination.destination_id}'">
                                Explore ${destination.name}
                            </button>
                        </div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading featured destinations:', error);
    }
}

// Test function for debugging
window.testSearchDirect = function(term = 'Paris') {
    console.log('Testing direct search for:', term);
    window.location.href = `actions/search_destinations.php?q=${encodeURIComponent(term)}`;
};