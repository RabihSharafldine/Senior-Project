

class DestinationsManager {
    constructor() {
        this.currentPage = 1;
        this.currentRegion = '';
        this.currentSort = 'popular';
        this.isLoading = false;
        this.hasMore = true;
        
        this.init();
    }

    init() {
        console.log('DestinationsManager initialized');
        this.bindEvents();
        this.loadDestinations();
    }

    bindEvents() {
        const regionFilter = document.getElementById('regionFilter');
        const sortFilter = document.getElementById('sortFilter');
        const loadMoreBtn = document.getElementById('loadMoreBtn');

        if (regionFilter) {
            regionFilter.addEventListener('change', (e) => {
                this.currentRegion = e.target.value;
                this.currentPage = 1;
                this.loadDestinations(true);
            });
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.currentSort = e.target.value;
                this.currentPage = 1;
                this.loadDestinations(true);
            });
        }

        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', () => {
                this.currentPage++;
                this.loadDestinations(false);
            });
        }

        // Category filter
        const categoryCards = document.querySelectorAll('.category-card');
        categoryCards.forEach(card => {
            card.addEventListener('click', () => {
                const category = card.getAttribute('data-category');
                this.filterByCategory(category);
            });
        });
    }

async loadDestinations(clearExisting = false) {
    if (this.isLoading) return;
    
    this.isLoading = true;
    this.toggleLoadingState(true);

    try {
        const params = new URLSearchParams({
            region: this.currentRegion,
            sort: this.currentSort,
            page: this.currentPage
        });

        const response = await fetch(`actions/get_destinations.php?${params}`);
        const data = await response.json();

        if (data.success) {
            if (clearExisting) {
                document.getElementById('allDestinations').innerHTML = '';
            }
            
            this.renderDestinations(data.destinations);
            this.hasMore = data.hasMore;
            this.updateLoadMoreButton();
            
            // Hide loading spinner after content is rendered
            this.hideLoadingSpinner();
        } else {
            this.showError(data.message || 'Failed to load destinations');
        }
    } catch (error) {
        console.error('Error loading destinations:', error);
        this.showError('Failed to load destinations. Please try again.');
    } finally {
        this.isLoading = false;
        this.toggleLoadingState(false);
    }
}
hideLoadingSpinner() {
    const loadingSpinner = document.querySelector('.loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.style.display = 'none';
    }
}

    renderDestinations(destinations) {
        const container = document.getElementById('allDestinations');
        
        if (destinations.length === 0 && this.currentPage === 1) {
            container.innerHTML = `
                <div class="no-results" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                    <i class="fas fa-map-marker-alt" style="font-size: 3rem; color: #666; margin-bottom: 1rem;"></i>
                    <h3 style="color: #2c3e50; margin-bottom: 1rem;">No destinations found</h3>
                    <p style="color: #666;">Try adjusting your filters or search terms</p>
                </div>
            `;
            return;
        }

        destinations.forEach(destination => {
            const destinationCard = this.createDestinationCard(destination);
            container.appendChild(destinationCard);
        });
    }
createDestinationCard(destination) {
    const card = document.createElement('div');
    card.className = 'destination-card';
    
    card.innerHTML = `
        <div class="destination-image">
            <img src="${destination.image_url}" alt="${destination.name}" 
                 style="width: 100%; height: 200px; object-fit: cover;"
                 onerror="handleImageError(this, '${destination.name}')">
        </div>
        <div class="destination-content">
            <h3>${destination.name}</h3>
            <div class="destination-location">
                <i class="fas fa-map-marker-alt"></i>
                ${destination.country}
            </div>
            <p class="destination-description">${destination.description}</p>
            
            <div class="destination-features">
                <div class="destination-feature">
                    <div class="feature-value">${destination.avg_rating}</div>
                    <div class="feature-label">Rating</div>
                </div>
                <div class="destination-feature">
                    <div class="feature-value">${destination.review_count}</div>
                    <div class="feature-label">Reviews</div>
                </div>
            </div>
            
            <div class="card-actions" style="display: flex; flex-direction: column; gap: 10px; margin-top: 15px;">
                <button class="btn btn-primary btn-sm" onclick="chooseAccommodation(${destination.destination_id}, '${destination.name.replace("'", "\\'")}', '${destination.country.replace("'", "\\'")}')" style="width: 100%;">
                    <i class="fas fa-bed"></i> Choose Accommodation
                </button>
                <div style="display: flex; gap: 10px;">
                    <button class="btn btn-outline btn-sm" onclick="viewDestinationDetails(${destination.destination_id})" style="flex: 1;">
                        <i class="fas fa-eye"></i> Details
                    </button>
                   <button class="btn btn-outline btn-large" onclick="addToWishlist(<?php echo $destination_id; ?>)">
    <i class="fas fa-heart"></i> Save
</button>

                </div>
            </div>
        </div>
    `;
    
    return card;
}

    filterByCategory(category) {
        const categoryMap = {
            'beach': 'oceania',
            'mountain': 'europe', 
            'city': 'europe',
            'cultural': 'asia'
        };
        
        this.currentRegion = categoryMap[category] || '';
        this.currentPage = 1;
        this.loadDestinations(true);
        
        const regionFilter = document.getElementById('regionFilter');
        if (regionFilter) {
            regionFilter.value = this.currentRegion;
        }
    }

    updateLoadMoreButton() {
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        if (loadMoreBtn) {
            loadMoreBtn.style.display = this.hasMore ? 'block' : 'none';
        }
    }

    toggleLoadingState(loading) {
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    
    if (loadMoreBtn) {
        loadMoreBtn.disabled = loading;
        loadMoreBtn.innerHTML = loading ? 
            '<i class="fas fa-spinner fa-spin"></i> Loading...' : 
            'Load More Destinations';
    }
    
    // Don't show loading spinner for subsequent pages (page > 1)
    if (loading && this.currentPage === 1) {
        const container = document.getElementById('allDestinations');
        if (container.children.length === 0) {
            container.innerHTML = `
                <div class="loading-spinner" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                    <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: #3498db; margin-bottom: 1rem;"></i>
                    <p style="color: #666;">Loading destinations...</p>
                </div>
            `;
        }
    }
}

    showError(message) {
        const container = document.getElementById('allDestinations');
        container.innerHTML = `
            <div class="error-message" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #e74c3c; margin-bottom: 1rem;"></i>
                <h3 style="color: #2c3e50; margin-bottom: 1rem;">Error</h3>
                <p style="color: #666; margin-bottom: 1.5rem;">${message}</p>
                <button class="btn btn-primary" onclick="window.destinationsManager.loadDestinations(true)">
                    Try Again
                </button>
            </div>
        `;
    }
}

function handleImageError(img, destinationName) {
    console.log(`Image failed: ${img.src}`);
    
    // Only try one fallback to prevent loops
    if (!img.src.includes('default.jpg')) {
        img.src = 'images/destinations/default.jpg';
        img.onerror = null; // Remove error handler to prevent loop
    } else {
        // If default also fails, show placeholder
        img.alt = `Image not available for ${destinationName}`;
        img.style.backgroundColor = '#f0f0f0';
        img.style.display = 'flex';
        img.style.alignItems = 'center';
        img.style.justifyContent = 'center';
        img.style.color = '#666';
        img.innerHTML = `<div style="text-align: center;">📷<br>Image<br>Not Found</div>`;
    }
}

// Add this debug function to check what's happening
function debugImages() {
    console.log('=== DEBUG IMAGES ===');
    const images = document.querySelectorAll('.destination-image img');
    images.forEach((img, index) => {
        console.log(`Image ${index + 1}:`, {
            src: img.src,
            complete: img.complete,
            naturalWidth: img.naturalWidth,
            naturalHeight: img.naturalHeight,
            loaded: img.naturalWidth > 0
        });
    });
}

// Global functions - keep these the same
function chooseAccommodation(destinationId, destinationName, destinationCountry) {
    console.log('Choosing accommodation for:', destinationName, destinationCountry);
    
    const destinationData = {
        id: destinationId,
        name: destinationName,
        country: destinationCountry,
        timestamp: new Date().getTime()
    };
    
    sessionStorage.setItem('selectedDestination', JSON.stringify(destinationData));
    console.log('Destination saved to sessionStorage:', destinationData);
    
    window.location.href = 'accommodations.php';
}

function viewDestinationDetails(destinationId) {
    console.log('View details for destination:', destinationId);
    window.location.href = `destination-details.php?id=${destinationId}`;
}

function addToWishlist(destinationId) {
    console.log('Add to wishlist:', destinationId);
    if (confirm('Add this destination to your wishlist?')) {
        fetch('actions/add_to_wishlist.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ destination_id: destinationId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Destination added to wishlist!');
            } else {
                alert('Please login to add to wishlist');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error adding to wishlist');
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing DestinationsManager...');
    window.destinationsManager = new DestinationsManager();
    
    // Run debug after content loads
    setTimeout(debugDestinations, 1000);
});
